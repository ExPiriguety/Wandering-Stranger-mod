import math, sys, numpy as np
from PIL import Image
TEX = Image.open('src/main/resources/assets/wandering_stranger/textures/entity/stranger.png').convert('RGBA')
T = np.array(TEX)

def rotx(a):
    c,s=math.cos(a),math.sin(a)
    return np.array([[1,0,0],[0,c,-s],[0,s,c]])

# part: name, parent, pivot(x,y,z), rotx, cubes[(u,v,x,y,z,w,h,d,grow,mirror)]
def model(BP_Y=5.8, ARM_ROT=-0.75):
    P=[]
    P.append(('head',None,(0,0,0),0,[(0,44,-4,-10,-4,8,10,8,0,False)]))
    P.append(('headwear','head',(0,0,0),0,[(0,24,-4,-10,-6,8,10,10,0.51,False)]))
    P.append(('nose','head',(0,-2,0),0,[(0,0,-1,-1,-6,2,4,2,0,False)]))
    P.append(('body',None,(0,0,0),0,[(58,55,-4,0,-3,8,12,6,0,False)]))
    P.append(('bodywear','body',(0,0,0),0,[(36,35,-4,0,-3,8,20,6,0.5,False)]))
    P.append(('backpack','body',(0,BP_Y,8.5),0,[
        (0,0,-8,-7.8,-5.5,16,16,8,0,False),(48,0,-7,-2.8,2.5,14,11,3,0,False),
        (64,35,-11,0.2,-4.5,3,7,6,0,False),(36,24,-8,-12.8,-2.5,16,5,6,0,False),
        (64,35,8,0.2,-4.5,3,7,6,0,True)]))
    P.append(('arms',None,(0,2.95,1.05),ARM_ROT,[
        (0,62,-4,2,-4.1,8,4,4,0,False),(44,69,4,-2,-4.1,4,8,4,0,False),
        (48,14,-8,6,-4.1,16,2,4,0,False),(44,69,-8,-2,-4.1,4,8,4,0,True)]))
    P.append(('right_leg',None,(-2,12,0),0,[(28,61,-2,0,-2,4,12,4,0,False)]))
    P.append(('left_leg',None,(2,12,0),0,[(28,61,-2,0,-2,4,12,4,0,True)]))
    return P

def world_transform(parts):
    d={p[0]:p for p in parts}
    def chain(n):
        res=[]
        while n: res.append(d[n]); n=d[n][1]
        return res[::-1]
    out={}
    for p in parts:
        # compose: pos = sum pivots with rotations
        R=np.eye(3); pos=np.zeros(3)
        for q in chain(p[0]):
            pos = pos + R@np.array(q[2],float)
            R = R@rotx(q[3])
        out[p[0]]=(pos,R)
    return out

def sample_cube(c, step=0.1):
    u0,v0,x,y,z,w,h,d,g,mir=c
    x0,x1=x-g,x+w+g; y0,y1=y-g,y+h+g; z0,z1=z-g,z+d+g
    pts=[]
    def rng(a,b): 
        n=max(2,int((b-a)/step)+1); return np.linspace(a,b,n)
    def tex(face,a,b):
        # a,b in [0,1] fractions along the face's two axes
        if face=='front':   # z=min, a along +x, b along +y
            u=u0+d+a*w; v=v0+d+b*h
        elif face=='back':  # z=max, a along -x
            u=u0+2*d+w+a*w; v=v0+d+b*h
        elif face=='west':  # x=min, a along -z (front->back)
            u=u0+d-a*d; v=v0+d+b*h
        elif face=='east':
            u=u0+d+w+a*d; v=v0+d+b*h
        elif face=='top':   # y=min, a along +x, b along -z
            u=u0+d+a*w; v=v0+d-b*d
        else:               # bottom
            u=u0+d+w+a*w; v=v0+d-b*d
        if mir:
            # mirror horizontally inside the whole cube strip
            tot=2*d+2*w
            u=u0+tot-(u-u0)
        return u,v
    res=[]
    for face in ['front','back','west','east','top','bottom']:
        for a in np.linspace(0,1,int(max(w,d)/step)+2):
            for b in np.linspace(0,1,int(max(h,d)/step)+2):
                if face=='front': P=(x0+a*(x1-x0), y0+b*(y1-y0), z0)
                elif face=='back': P=(x1-a*(x1-x0), y0+b*(y1-y0), z1)
                elif face=='west': P=(x0, y0+b*(y1-y0), z0+a*(z1-z0))
                elif face=='east': P=(x1, y0+b*(y1-y0), z1-a*(z1-z0)) if False else (x1, y0+b*(y1-y0), z0+a*(z1-z0))
                elif face=='top': P=(x0+a*(x1-x0), y0, z1-b*(z1-z0))
                else: P=(x0+a*(x1-x0), y1, z1-b*(z1-z0))
                u,v=tex(face,a,b)
                res.append((P,u,v,face))
    return res

def render(parts, view, scale=10, size=(420,420)):
    W,H=size; img=np.zeros((H,W,4),np.uint8); img[:]=(40,42,48,255)
    zb=np.full((H,W),1e9)
    tr=world_transform(parts)
    for p in parts:
        pos,R=tr[p[0]]
        for c in p[4]:
            for (P,u,v,face) in sample_cube(c):
                q=pos+R@np.array(P,float)
                X,Y,Z=q
                if view=='front': sx,sy,dz=X,Y,Z
                elif view=='back': sx,sy,dz=-X,Y,-Z
                elif view=='3q':
                    th=math.radians(-35); sx=X*math.cos(th)+Z*math.sin(th); sy=Y; dz=-X*math.sin(th)+Z*math.cos(th)
                elif view=='side': sx,sy,dz=Z,Y,-X   # looking from +x side
                else: sx,sy,dz=-Z,Y,X
                px=int(W/2+sx*scale); py=int(H-20-(24-Y)*scale)
                for ddx in (0,1):
                    for ddy in (0,1):
                        xx,yy=px+ddx,py+ddy
                        if 0<=xx<W and 0<=yy<H and dz<zb[yy,xx]:
                            ui=int(min(127,max(0,math.floor(u)))); vi=int(min(127,max(0,math.floor(v))))
                            col=T[vi,ui]
                            if col[3]>20:
                                zb[yy,xx]=dz; img[yy,xx]=col
    # ground
    img[H-20:H-19,:]=(90,160,90,255)
    return Image.fromarray(img)

if __name__=='__main__':
    bp=float(sys.argv[1]); ar=float(sys.argv[2]); out=sys.argv[3]
    parts=model(bp,ar)
    views=['front','3q','side','back']
    ims=[render(parts,v) for v in views]
    sheet=Image.new('RGBA',(420*4,420)); 
    for i,im in enumerate(ims): sheet.paste(im,(420*i,0))
    sheet.save(out)
