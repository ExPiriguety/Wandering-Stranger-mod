"""Renders the Wandering Stranger bust (real model + texture, ray-traced, lit) into the mod icon.
Run from the project root:  python tools/render_icon.py [yaw_deg] [out.png]   (512x512; resize to 256 for logo.png)
Needs numpy + Pillow. Uses the cuboid layout of client/StrangerModel.java (keep both in sync)."""
import math, sys, random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

TEX = np.array(Image.open('src/main/resources/assets/wandering_stranger/textures/entity/stranger.png').convert('RGBA'))

def rotx(a):
    c, s = math.cos(a), math.sin(a); return np.array([[1,0,0],[0,c,-s],[0,s,c]])
def roty(a):
    c, s = math.cos(a), math.sin(a); return np.array([[c,0,s],[0,1,0],[-s,0,c]])

BP_Y, ARM_ROT = 5.8, -0.75
PARTS = [
 ('head', None, (0,0,0), 0, [(0,44,-4,-10,-4,8,10,8,0,False)]),
 ('headwear','head',(0,0,0),0,[(0,24,-4,-10,-6,8,10,10,0.51,False)]),
 ('nose','head',(0,-2,0),0,[(0,0,-1,-1,-6,2,4,2,0,False)]),
 ('body',None,(0,0,0),0,[(58,55,-4,0,-3,8,12,6,0,False)]),
 ('bodywear','body',(0,0,0),0,[(36,35,-4,0,-3,8,20,6,0.5,False)]),
 ('backpack','body',(0,BP_Y,8.5),0,[
    (0,0,-8,-7.8,-5.5,16,16,8,0,False),(48,0,-7,-2.8,2.5,14,11,3,0,False),
    (64,35,-11,0.2,-4.5,3,7,6,0,False),(36,24,-8,-12.8,-2.5,16,5,6,0,False),
    (64,35,8,0.2,-4.5,3,7,6,0,True)]),
 ('arms',None,(0,2.95,1.05),ARM_ROT,[
    (0,62,-4,2,-4.1,8,4,4,0,False),(44,69,4,-2,-4.1,4,8,4,0,False),
    (48,14,-8,6,-4.1,16,2,4,0,False),(44,69,-8,-2,-4.1,4,8,4,0,True)]),
 ('right_leg',None,(-2,12,0),0,[(28,61,-2,0,-2,4,12,4,0,False)]),
 ('left_leg',None,(2,12,0),0,[(28,61,-2,0,-2,4,12,4,0,True)]),
]

def part_transforms():
    d = {p[0]: p for p in PARTS}
    out = {}
    for p in PARTS:
        chain, n = [], p[0]
        while n: chain.append(d[n]); n = d[n][1]
        R = np.eye(3); pos = np.zeros(3)
        for q in chain[::-1]:
            pos = pos + R @ np.array(q[2], float); R = R @ rotx(q[3])
        out[p[0]] = (pos, R)
    return out

def render(size, yaw, pitch, center, span, ss=2):
    W = size * ss
    Rc = rotx(math.radians(pitch)) @ roty(math.radians(yaw))      # model -> camera
    Rt = Rc.T
    lin = (np.arange(W) + 0.5) / W - 0.5
    sx = center[0] + lin * span
    sy = center[1] + lin * span
    SX, SY = np.meshgrid(sx, sy)
    o_c = np.stack([SX, SY, np.full_like(SX, -300.0)], -1).reshape(-1, 3)
    o_m = o_c @ Rt.T                      # rows: Rt @ o
    d_m = (Rt @ np.array([0, 0, 1.0]))
    best_t = np.full(o_m.shape[0], 1e9)
    col = np.zeros((o_m.shape[0], 3)); hit = np.zeros(o_m.shape[0], bool)
    L = np.array([-0.55, -0.75, -0.65]); L /= np.linalg.norm(L)    # light, camera space (towards light)
    tr = part_transforms()
    for p in PARTS:
        pos, R = tr[p[0]]
        o_l = (o_m - pos) @ R                # R^T (o - pos)  (row-vector form)
        d_l = R.T @ d_m
        for (u0, v0, x, y, z, w, h, d, g, mir) in p[4]:
            lo = np.array([x - g, y - g, z - g]); hi = np.array([x + w + g, y + h + g, z + d + g])
            with np.errstate(divide='ignore', invalid='ignore'):
                t1 = (lo - o_l) / d_l; t2 = (hi - o_l) / d_l
            tmin = np.minimum(t1, t2); tmax = np.maximum(t1, t2)
            tn = tmin.max(1); tf = tmax.min(1)
            ok = (tn <= tf) & (tf > 0) & (tn < best_t)
            if not ok.any(): continue
            idx = np.where(ok)[0]
            axis = tmin[idx].argmax(1)
            P = o_l[idx] + tn[idx, None] * d_l
            fx = (P[:,0]-lo[0])/(hi[0]-lo[0]); fy = (P[:,1]-lo[1])/(hi[1]-lo[1]); fz = (P[:,2]-lo[2])/(hi[2]-lo[2])
            sgn = np.where(d_l[axis] > 0, -1.0, 1.0)      # normal sign along the axis
            u = np.zeros(len(idx)); v = np.zeros(len(idx))
            # axis 0 = x faces, 1 = y faces, 2 = z faces ; sign<0 means the min side (west/top/front)
            m = (axis == 2) & (sgn < 0)   # front (z min)
            u[m] = u0 + d + fx[m]*w;            v[m] = v0 + d + fy[m]*h
            m = (axis == 2) & (sgn > 0)   # back
            u[m] = u0 + 2*d + w + (1-fx[m])*w;  v[m] = v0 + d + fy[m]*h
            m = (axis == 0) & (sgn < 0)   # west
            u[m] = u0 + d - fz[m]*d;            v[m] = v0 + d + fy[m]*h
            m = (axis == 0) & (sgn > 0)   # east
            u[m] = u0 + d + w + fz[m]*d;        v[m] = v0 + d + fy[m]*h
            m = (axis == 1) & (sgn < 0)   # top
            u[m] = u0 + d + fx[m]*w;            v[m] = v0 + d - (1-fz[m])*d
            m = (axis == 1) & (sgn > 0)   # bottom
            u[m] = u0 + d + w + fx[m]*w;        v[m] = v0 + d - (1-fz[m])*d
            if mir: u = u0 + (2*d + 2*w) - (u - u0)
            ui = np.clip(np.floor(u).astype(int), 0, 127); vi = np.clip(np.floor(v).astype(int), 0, 127)
            texel = TEX[vi, ui]
            opaque = texel[:, 3] > 40
            if not opaque.any(): continue
            sel = idx[opaque]
            nl = np.zeros((len(idx), 3)); nl[np.arange(len(idx)), axis] = sgn
            n_cam = (Rc @ (R @ nl.T)).T
            lam = np.clip(n_cam @ L, 0, 1)
            shade = 0.46 + 0.62 * lam
            c = texel[:, :3].astype(float) * shade[:, None]
            # warm tint on lit faces
            c = c * (1 + 0.10 * lam[:, None] * np.array([1.0, 0.55, 0.1]))
            col[sel] = c[opaque]; best_t[sel] = tn[idx][opaque]; hit[sel] = True
    img = np.zeros((W, W, 4), np.uint8)
    img[..., :3] = np.clip(col, 0, 255).reshape(W, W, 3).astype(np.uint8)
    img[..., 3] = (hit.reshape(W, W) * 255).astype(np.uint8)
    return Image.fromarray(img, 'RGBA')

def background(S):
    y, x = np.mgrid[0:S, 0:S] / (S - 1)
    top = np.array([16, 18, 38.]); bot = np.array([66, 34, 34.])
    bg = top[None, None] * (1 - y[..., None]) + bot[None, None] * y[..., None]
    # warm lantern-like glow lower left, cool glow upper right
    g1 = np.exp(-(((x - 0.22) ** 2 + (y - 0.78) ** 2) / 0.05))[..., None] * np.array([255, 150, 60.]) * 0.42
    g2 = np.exp(-(((x - 0.70) ** 2 + (y - 0.30) ** 2) / 0.10))[..., None] * np.array([90, 70, 150.]) * 0.30
    bg = bg + g1 + g2
    vig = 1 - 0.55 * (((x - 0.5) ** 2 + (y - 0.5) ** 2) * 2.0)
    bg *= np.clip(vig, 0.35, 1)[..., None]
    im = Image.fromarray(np.clip(bg, 0, 255).astype(np.uint8), 'RGB').convert('RGBA')
    # soft bokeh dust
    rnd = random.Random(11); dust = Image.new('RGBA', (S, S), (0, 0, 0, 0)); dd = ImageDraw.Draw(dust)
    for _ in range(26):
        cx, cy, r = rnd.randint(0, S), rnd.randint(0, int(S * .8)), rnd.randint(S // 90, S // 38)
        a = rnd.randint(18, 48); dd.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(255, 205, 130, a))
    dust = dust.filter(ImageFilter.GaussianBlur(S / 160))
    return Image.alpha_composite(im, dust)

def make(S=512, yaw=-24, pitch=8):
    fig = render(S, yaw, pitch, center=(1.8, -2.5), span=26.0, ss=2).resize((S, S), Image.LANCZOS)
    bg = background(S)
    # drop shadow of the figure
    sh = Image.new('RGBA', (S, S), (0, 0, 0, 0)); sh.putalpha(fig.split()[3].point(lambda a: int(a * 0.55)))
    sh = sh.filter(ImageFilter.GaussianBlur(S / 55)); sh = Image.composite(Image.new('RGBA', (S, S), (0, 0, 0, 255)), Image.new('RGBA', (S, S), (0, 0, 0, 0)), sh.split()[3])
    out = Image.alpha_composite(bg, sh.filter(ImageFilter.GaussianBlur(1)))
    out = Image.alpha_composite(out, fig)
    # frame + rounded corners (supersampled mask)
    k = 4; M = Image.new('L', (S * k, S * k), 0); md = ImageDraw.Draw(M)
    rad = int(S * 0.085 * k); md.rounded_rectangle([0, 0, S * k - 1, S * k - 1], rad, fill=255)
    mask = M.resize((S, S), Image.LANCZOS)
    fr = Image.new('RGBA', (S * k, S * k), (0, 0, 0, 0)); fd = ImageDraw.Draw(fr)
    bw = int(S * 0.018 * k)
    fd.rounded_rectangle([0, 0, S * k - 1, S * k - 1], rad, outline=(214, 172, 52, 255), width=bw)
    fd.rounded_rectangle([bw, bw, S * k - 1 - bw, S * k - 1 - bw], rad - bw, outline=(90, 64, 14, 255), width=max(2, bw // 3))
    fr = fr.resize((S, S), Image.LANCZOS)
    out = Image.alpha_composite(out, fr)
    out.putalpha(Image.composite(out.split()[3], Image.new('L', (S, S), 0), mask))
    return out

if __name__ == '__main__':
    yaw = float(sys.argv[1]) if len(sys.argv) > 1 else -24.0
    path = sys.argv[2] if len(sys.argv) > 2 else 'icon_512.png'
    make(512, yaw).save(path)
    print('saved', path)
