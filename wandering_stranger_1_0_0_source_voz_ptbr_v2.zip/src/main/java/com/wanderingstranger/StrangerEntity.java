package com.wanderingstranger;

import com.wanderingstranger.spawn.SpawnSettings;
import com.wanderingstranger.spawn.StrangerSpawner;
import com.wanderingstranger.trades.StrangerTrades;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;

/**
 * Extends the vanilla WanderingTrader so other mods keep treating it as a trader.
 * Offers are generated ONCE and saved in the entity NBT, so they survive restarts.
 * When leaveAt is set (natural spawn) the stranger leaves by itself at that game time.
 */
public class StrangerEntity extends WanderingTrader {
    private long leaveAt = -1L;

    public StrangerEntity(EntityType<? extends WanderingTrader> type, Level level) {
        super(type, level);
    }

    public void setLeaveAt(long gameTime) {
        this.leaveAt = gameTime;
    }

    @Override
    protected void updateTrades() {
        MerchantOffers offers = this.getOffers();
        int added = StrangerTrades.fillOffers(offers, this.random);
        if (added == 0) {
            super.updateTrades();
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.leaveAt >= 0 && this.tickCount % 20 == 0
                && this.level().getGameTime() >= this.leaveAt
                && !(SpawnSettings.waitIfTrading && this.isTrading())) {
            this.leave();
        }
    }

    private void leave() {
        if (this.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.POOF, this.getX(), this.getY() + 1.0D, this.getZ(),
                    25, 0.3D, 0.6D, 0.3D, 0.02D);
            StrangerSpawner.announceLeave(serverLevel.getServer());
            StrangerSpawner.notifyGone(serverLevel.getServer(), this.getUUID());
        }
        this.discard();
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (this.level() instanceof ServerLevel serverLevel) {
            StrangerSpawner.notifyGone(serverLevel.getServer(), this.getUUID());
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putLong("StrangerLeaveAt", this.leaveAt);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.leaveAt = tag.contains("StrangerLeaveAt") ? tag.getLong("StrangerLeaveAt") : -1L;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return this.isTrading() ? ModSounds.TRADE.get() : ModSounds.AMBIENT.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.DEATH.get();
    }

    @Override
    protected SoundEvent getDrinkingSound(ItemStack stack) {
        return stack.is(Items.MILK_BUCKET) ? ModSounds.DRINK_MILK.get() : ModSounds.DRINK_POTION.get();
    }

    @Override
    protected SoundEvent getTradeUpdatedSound(boolean success) {
        return success ? ModSounds.YES.get() : ModSounds.NO.get();
    }

    @Override
    public SoundEvent getNotifyTradeSound() {
        return ModSounds.YES.get();
    }
}
