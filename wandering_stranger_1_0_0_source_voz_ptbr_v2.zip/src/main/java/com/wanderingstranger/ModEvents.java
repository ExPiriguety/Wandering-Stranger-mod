package com.wanderingstranger;

import com.wanderingstranger.command.StrangerCommand;
import com.wanderingstranger.spawn.StrangerSpawner;
import com.wanderingstranger.trades.StrangerTrades;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public final class ModEvents {

    @Mod.EventBusSubscriber(modid = WanderingStrangerMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        @SubscribeEvent
        public static void onAttributes(EntityAttributeCreationEvent event) {
            event.put(ModEntities.STRANGER.get(), Mob.createMobAttributes().build());
        }
    }

    @Mod.EventBusSubscriber(modid = WanderingStrangerMod.MOD_ID)
    public static final class ForgeBus {
        @SubscribeEvent
        public static void onCommands(RegisterCommandsEvent event) {
            StrangerCommand.register(event.getDispatcher());
        }

        @SubscribeEvent
        public static void onServerStarting(ServerStartingEvent event) {
            StrangerTrades.reload();
        }

        @SubscribeEvent
        public static void onServerStarted(ServerStartedEvent event) {
            StrangerSpawner.applyVanillaMode(event.getServer());
        }

        @SubscribeEvent
        public static void onLevelTick(TickEvent.LevelTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            if (!(event.level instanceof ServerLevel serverLevel)) return;
            if (serverLevel.dimension() != Level.OVERWORLD) return;
            if (serverLevel.getGameTime() % 20L != 0L) return;
            StrangerSpawner.tick(serverLevel);
        }

        /** "vanilla_trader": "remove" -> vanilla wandering traders and trader llamas never enter the world. */
        @SubscribeEvent
        public static void onEntityJoin(EntityJoinLevelEvent event) {
            if (event.getLevel().isClientSide()) return;
            if (!StrangerSpawner.removeVanillaTraders()) return;
            EntityType<?> type = event.getEntity().getType();
            if (type == EntityType.WANDERING_TRADER || type == EntityType.TRADER_LLAMA) {
                event.setCanceled(true);
            }
        }
    }

    private ModEvents() {}
}
