package com.wanderingstranger.client;

import com.wanderingstranger.WanderingStrangerMod;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.File;

/** Opened by the "Config" button of the Mods list: shows where the config lives and opens the folder. */
public class ConfigInfoScreen extends Screen {
    private final Screen parent;

    public ConfigInfoScreen(Screen parent) {
        super(Component.translatable("gui.wandering_stranger.config.title"));
        this.parent = parent;
    }

    private static File dir() {
        return FMLPaths.CONFIGDIR.get().resolve(WanderingStrangerMod.MOD_ID).toFile();
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2;
        addRenderableWidget(Button.builder(Component.translatable("gui.wandering_stranger.config.open"), b -> {
            File d = dir();
            d.mkdirs();
            Util.getPlatform().openFile(d);
        }).bounds(cx - 100, y + 34, 200, 20).build());
        addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose())
                .bounds(cx - 100, y + 58, 200, 20).build());
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        this.renderBackground(g);
        int cx = this.width / 2;
        int y = this.height / 2;
        g.drawCenteredString(this.font, this.title, cx, y - 64, 0xFFE8C766);
        g.drawCenteredString(this.font, Component.translatable("gui.wandering_stranger.config.file"), cx, y - 44, 0xFFE0E0E0);
        g.drawCenteredString(this.font, this.font.plainSubstrByWidth(dir().getPath() + File.separator + "trades.json",
                this.width - 20), cx, y - 30, 0xFF8A8A8A);
        g.drawCenteredString(this.font, Component.translatable("gui.wandering_stranger.config.help1"), cx, y - 10, 0xFFE0E0E0);
        g.drawCenteredString(this.font, Component.translatable("gui.wandering_stranger.config.help2"), cx, y + 4, 0xFFE0E0E0);
        super.render(g, mx, my, pt);
    }
}
