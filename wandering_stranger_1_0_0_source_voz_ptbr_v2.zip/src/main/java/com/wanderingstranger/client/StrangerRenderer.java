package com.wanderingstranger.client;

import com.wanderingstranger.StrangerEntity;
import com.wanderingstranger.WanderingStrangerMod;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class StrangerRenderer extends MobRenderer<StrangerEntity, StrangerModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(WanderingStrangerMod.MOD_ID, "textures/entity/stranger.png");

    public StrangerRenderer(EntityRendererProvider.Context context) {
        super(context, new StrangerModel(context.bakeLayer(StrangerModel.LAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(StrangerEntity entity) {
        return TEXTURE;
    }
}
