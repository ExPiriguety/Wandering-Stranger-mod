package com.wanderingstranger.client;

import com.wanderingstranger.client.gui.EditorData;
import com.wanderingstranger.client.gui.EditorScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

public final class ClientHooks {
    public static void openEditor(String json) {
        Minecraft mc = Minecraft.getInstance();
        try {
            mc.setScreen(new EditorScreen(EditorData.fromJson(json)));
        } catch (Exception e) {
            if (mc.player != null) {
                mc.player.displayClientMessage(Component.translatable("command.wandering_stranger.editor_error", String.valueOf(e.getMessage())), false);
            }
        }
    }

    private ClientHooks() {}
}
