package com.wanderingstranger.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.wanderingstranger.StrangerEntity;
import com.wanderingstranger.WanderingStrangerMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Hand-converted from the OptiFine CEM model (wandering_trader.jem, 128x128 texture).
 * Conversion rules used: pivot_y = 24 + translate_y ; box_y = pivot_up - y - height.
 * If a part looks misplaced in game, tweak the numbers below (BACKPACK_Y, arms pivot...).
 */
public class StrangerModel extends EntityModel<StrangerEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(WanderingStrangerMod.MOD_ID, "stranger"), "main");

    // Tunables (vanilla model space: +y is DOWN, ground is y = 24)
    private static final float BACKPACK_Y = 5.8F;
    private static final float BACKPACK_Z = 8.5F;

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public StrangerModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition head = root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 44).addBox(-4F, -10F, -4F, 8F, 10F, 8F),
                PartPose.ZERO);
        head.addOrReplaceChild("headwear",
                CubeListBuilder.create().texOffs(0, 24)
                        .addBox(-4F, -10F, -6F, 8F, 10F, 10F, new CubeDeformation(0.51F)),
                PartPose.ZERO);
        head.addOrReplaceChild("nose",
                CubeListBuilder.create().texOffs(0, 0).addBox(-1F, -1F, -6F, 2F, 4F, 2F),
                PartPose.offset(0F, -2F, 0F));

        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(58, 55).addBox(-4F, 0F, -3F, 8F, 12F, 6F),
                PartPose.ZERO);
        body.addOrReplaceChild("bodywear",
                CubeListBuilder.create().texOffs(36, 35)
                        .addBox(-4F, 0F, -3F, 8F, 20F, 6F, new CubeDeformation(0.5F)),
                PartPose.ZERO);

        body.addOrReplaceChild("backpack",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-8F, -7.8F, -5.5F, 16F, 16F, 8F)
                        .texOffs(48, 0).addBox(-7F, -2.8F, 2.5F, 14F, 11F, 3F)
                        .texOffs(64, 35).addBox(-11F, 0.2F, -4.5F, 3F, 7F, 6F)
                        .texOffs(36, 24).addBox(-8F, -12.8F, -2.5F, 16F, 5F, 6F)
                        .texOffs(64, 35).mirror().addBox(8F, 0.2F, -4.5F, 3F, 7F, 6F),
                PartPose.offset(0F, BACKPACK_Y, BACKPACK_Z));

        root.addOrReplaceChild("arms",
                CubeListBuilder.create()
                        .texOffs(0, 62).addBox(-4F, 2F, -4.1F, 8F, 4F, 4F)
                        .texOffs(44, 69).addBox(4F, -2F, -4.1F, 4F, 8F, 4F)
                        .texOffs(48, 14).addBox(-8F, 6F, -4.1F, 16F, 2F, 4F)
                        .texOffs(44, 69).mirror().addBox(-8F, -2F, -4.1F, 4F, 8F, 4F),
                PartPose.offsetAndRotation(0F, 2.95F, 1.05F, -0.75F, 0F, 0F));

        root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(28, 61).addBox(-2F, 0F, -2F, 4F, 12F, 4F),
                PartPose.offset(-2F, 12F, 0F));
        root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(28, 61).mirror().addBox(-2F, 0F, -2F, 4F, 12F, 4F),
                PartPose.offset(2F, 12F, 0F));

        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(StrangerEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        this.head.xRot = headPitch * ((float) Math.PI / 180F);
        this.rightLeg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount * 0.5F;
        this.leftLeg.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.4F * limbSwingAmount * 0.5F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
