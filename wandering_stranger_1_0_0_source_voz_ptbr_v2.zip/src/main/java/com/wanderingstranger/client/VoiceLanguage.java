package com.wanderingstranger.client;

import com.wanderingstranger.WanderingStrangerMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Set;

/**
 * Client-side voice language switch.
 * The server always plays the default (English) voice lines. When a client's game language is
 * pt_br, this swaps them for the Portuguese set (entity.stranger.pt_br.*) right before playing.
 * Every other language keeps the original English voice. Each player hears their own language.
 */
@Mod.EventBusSubscriber(modid = WanderingStrangerMod.MOD_ID, value = Dist.CLIENT)
public final class VoiceLanguage {
    /** Game language codes that use the Portuguese voice. Add "pt_pt" here to include Portugal. */
    private static final Set<String> PT_LANGS = Set.of("pt_br");

    /** Sound events that have a Portuguese version (speech only; hurt/death/drink stay original). */
    private static final Set<String> TRANSLATED = Set.of("ambient", "trade", "yes", "no");

    private static final String PREFIX = "entity.stranger.";

    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent event) {
        SoundInstance original = event.getSound();
        if (original == null) return;

        ResourceLocation loc = original.getLocation();
        if (!WanderingStrangerMod.MOD_ID.equals(loc.getNamespace())) return;

        String path = loc.getPath();
        if (!path.startsWith(PREFIX)) return;
        String key = path.substring(PREFIX.length());
        if (!TRANSLATED.contains(key)) return; // also skips already-swapped pt_br.* events

        String lang = Minecraft.getInstance().options.languageCode;
        if (lang == null || !PT_LANGS.contains(lang.toLowerCase())) return;

        ResourceLocation ptLoc = new ResourceLocation(loc.getNamespace(), PREFIX + "pt_br." + key);
        event.setSound(new SimpleSoundInstance(
                ptLoc, original.getSource(), 1.0F, 1.0F, // getVolume()/getPitch() NPE before the sound is resolved
                RandomSource.create(), original.isLooping(), original.getDelay(),
                original.getAttenuation(), original.getX(), original.getY(), original.getZ(),
                original.isRelative()));
    }

    private VoiceLanguage() {}
}
