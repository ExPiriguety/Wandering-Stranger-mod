package com.wanderingstranger.client.gui;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.List;

/** Client-side editable copy of trades.json. */
public final class EditorData {
    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().create();

    public static final class Entry {
        public String id;
        public int count;
        public String nbt;

        public Entry(String id, int count, String nbt) {
            this.id = id;
            this.count = count;
            this.nbt = nbt;
        }

        public Entry copy() {
            return new Entry(id, count, nbt);
        }
    }

    public static final class Trade {
        public Entry a = new Entry("$currency", 1, null);
        public Entry b = null;
        public Entry result = new Entry("minecraft:apple", 1, null);
        public int maxUses = 12;
        public int xp = 1;
        public float mult = 0.05F;

        public Trade copy() {
            Trade t = new Trade();
            t.a = a.copy();
            t.b = b == null ? null : b.copy();
            t.result = result.copy();
            t.maxUses = maxUses;
            t.xp = xp;
            t.mult = mult;
            return t;
        }
    }

    public String currency = "minecraft:emerald";
    public int commonCount = 5;
    public int specialCount = 1;
    public final List<Trade> common = new ArrayList<>();
    public final List<Trade> special = new ArrayList<>();
    private final JsonObject extra = new JsonObject();

    public static EditorData fromJson(String json) {
        EditorData d = new EditorData();
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        for (java.util.Map.Entry<String, JsonElement> e : root.entrySet()) {
            String k = e.getKey();
            if (!k.equals("settings") && !k.equals("common") && !k.equals("special")) {
                d.extra.add(k, e.getValue());
            }
        }
        if (root.has("settings") && root.get("settings").isJsonObject()) {
            JsonObject s = root.getAsJsonObject("settings");
            if (s.has("currency")) d.currency = s.get("currency").getAsString();
            if (s.has("common_offers")) d.commonCount = s.get("common_offers").getAsInt();
            if (s.has("special_offers")) d.specialCount = s.get("special_offers").getAsInt();
        }
        readList(root, "common", d.common);
        readList(root, "special", d.special);
        return d;
    }

    private static void readList(JsonObject root, String key, List<Trade> out) {
        if (!root.has(key) || !root.get(key).isJsonArray()) return;
        for (JsonElement el : root.getAsJsonArray(key)) {
            try {
                JsonObject o = el.getAsJsonObject();
                JsonArray give = o.getAsJsonArray("give");
                Trade t = new Trade();
                t.a = readEntry(give.get(0).getAsJsonObject());
                t.b = give.size() > 1 ? readEntry(give.get(1).getAsJsonObject()) : null;
                t.result = readEntry(o.getAsJsonObject("get"));
                if (o.has("max_uses")) t.maxUses = o.get("max_uses").getAsInt();
                if (o.has("xp")) t.xp = o.get("xp").getAsInt();
                if (o.has("price_multiplier")) t.mult = o.get("price_multiplier").getAsFloat();
                out.add(t);
            } catch (Exception ignored) {
                // structurally broken entry: skipped by the editor
            }
        }
    }

    private static Entry readEntry(JsonObject o) {
        return new Entry(o.get("item").getAsString(),
                o.has("count") ? o.get("count").getAsInt() : 1,
                o.has("nbt") ? o.get("nbt").getAsString() : null);
    }

    private static JsonObject entryJson(Entry e) {
        JsonObject o = new JsonObject();
        o.addProperty("item", e.id);
        o.addProperty("count", Math.max(1, Math.min(64, e.count)));
        if (e.nbt != null && !e.nbt.isBlank()) o.addProperty("nbt", e.nbt);
        return o;
    }

    private static JsonArray listJson(List<Trade> list) {
        JsonArray arr = new JsonArray();
        for (Trade t : list) {
            JsonObject o = new JsonObject();
            JsonArray give = new JsonArray();
            give.add(entryJson(t.a));
            if (t.b != null) give.add(entryJson(t.b));
            o.add("give", give);
            o.add("get", entryJson(t.result));
            o.addProperty("max_uses", Math.max(1, t.maxUses));
            o.addProperty("xp", Math.max(0, t.xp));
            o.addProperty("price_multiplier", t.mult);
            arr.add(o);
        }
        return arr;
    }

    public String toJson() {
        JsonObject root = new JsonObject();
        for (java.util.Map.Entry<String, JsonElement> e : extra.entrySet()) root.add(e.getKey(), e.getValue());
        JsonObject s = new JsonObject();
        s.addProperty("currency", currency);
        s.addProperty("common_offers", commonCount);
        s.addProperty("special_offers", specialCount);
        root.add("settings", s);
        root.add("common", listJson(common));
        root.add("special", listJson(special));
        return GSON.toJson(root);
    }
}
