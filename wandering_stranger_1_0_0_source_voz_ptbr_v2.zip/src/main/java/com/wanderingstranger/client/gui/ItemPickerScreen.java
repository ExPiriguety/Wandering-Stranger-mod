package com.wanderingstranger.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/** Searchable grid with every registered item (vanilla, mods and KubeJS items). */
public class ItemPickerScreen extends Screen {
    private static final int COLS = 9;
    private static final int ROWS = 6;
    private static final int CELL = 20;
    private static List<Item> all;

    private final Screen parent;
    private final String currency;
    private final boolean allowClear;
    private final boolean allowCurrency;
    private final Consumer<EditorData.Entry> onPick;

    private EditBox search;
    private String query = "";
    private List<Item> filtered = new ArrayList<>();
    private int page;
    private int px, py, pw, ph, gridX, gridY;

    public ItemPickerScreen(Screen parent, String currency, boolean allowClear, boolean allowCurrency,
                            Consumer<EditorData.Entry> onPick) {
        super(Ui.t("picker.title"));
        this.parent = parent;
        this.currency = currency;
        this.allowClear = allowClear;
        this.allowCurrency = allowCurrency;
        this.onPick = onPick;
    }

    private static List<Item> allItems() {
        if (all == null) {
            List<Item> list = new ArrayList<>();
            for (Item i : ForgeRegistries.ITEMS.getValues()) {
                if (i != Items.AIR) list.add(i);
            }
            list.sort(Comparator.comparing(i -> String.valueOf(ForgeRegistries.ITEMS.getKey(i))));
            all = list;
        }
        return all;
    }

    @Override
    protected void init() {
        pw = COLS * CELL + 24;
        ph = 238;
        px = (this.width - pw) / 2;
        py = Math.max(2, (this.height - ph) / 2);
        gridX = px + 12;
        gridY = py + 46;

        search = new EditBox(this.font, px + 12, py + 22, pw - 24, 18, Ui.t("picker.search"));
        search.setMaxLength(64);
        search.setValue(query);
        search.setResponder(s -> {
            query = s;
            page = 0;
            applyFilter();
        });
        addRenderableWidget(search);
        setInitialFocus(search);

        int pagerY = gridY + ROWS * CELL + 4;
        addRenderableWidget(Button.builder(Component.literal("<"), b -> changePage(-1))
                .bounds(px + 12, pagerY, 24, 16).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> changePage(1))
                .bounds(px + pw - 36, pagerY, 24, 16).build());

        int by = pagerY + 22;
        int half = (pw - 24 - 4) / 2;
        addRenderableWidget(Button.builder(Ui.t("picker.hand"), b -> pickHand())
                .bounds(px + 12, by, half, 18).build());
        Button cur = addRenderableWidget(Button.builder(Ui.t("picker.currency"),
                        b -> pick(new EditorData.Entry("$currency", 1, null)))
                .bounds(px + 12 + half + 4, by, half, 18).build());
        cur.visible = allowCurrency;
        Button clear = addRenderableWidget(Button.builder(Ui.t("picker.clear"), b -> pick(null))
                .bounds(px + 12, by + 22, half, 18).build());
        clear.visible = allowClear;
        addRenderableWidget(Button.builder(Ui.t("picker.cancel"), b -> onClose())
                .bounds(px + 12 + half + 4, by + 22, half, 18).build());

        applyFilter();
    }

    private void applyFilter() {
        String q = query.trim().toLowerCase(Locale.ROOT);
        List<Item> out = new ArrayList<>();
        for (Item it : allItems()) {
            if (q.isEmpty()) {
                out.add(it);
                continue;
            }
            String key = String.valueOf(ForgeRegistries.ITEMS.getKey(it));
            if (key.contains(q) || new ItemStack(it).getHoverName().getString().toLowerCase(Locale.ROOT).contains(q)) {
                out.add(it);
            }
        }
        filtered = out;
        page = Math.min(page, pageCount() - 1);
    }

    private int pageCount() {
        return Math.max(1, (filtered.size() + COLS * ROWS - 1) / (COLS * ROWS));
    }

    private void changePage(int d) {
        page = Math.max(0, Math.min(pageCount() - 1, page + d));
    }

    private void pickHand() {
        Player p = Minecraft.getInstance().player;
        if (p == null) return;
        ItemStack s = p.getMainHandItem();
        if (s.isEmpty()) return;
        String id = String.valueOf(ForgeRegistries.ITEMS.getKey(s.getItem()));
        String nbt = s.hasTag() && s.getTag() != null ? s.getTag().toString() : null;
        pick(new EditorData.Entry(id, 1, nbt));
    }

    private void pick(EditorData.Entry e) {
        onPick.accept(e);
        Minecraft.getInstance().setScreen(parent);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (button != 0) return false;
        int per = COLS * ROWS;
        for (int i = 0; i < per; i++) {
            int idx = page * per + i;
            if (idx >= filtered.size()) break;
            int x = gridX + (i % COLS) * CELL;
            int y = gridY + (i / COLS) * CELL;
            if (Ui.inside(mx, my, x, y, CELL, CELL)) {
                String id = String.valueOf(ForgeRegistries.ITEMS.getKey(filtered.get(idx)));
                pick(new EditorData.Entry(id, 1, null));
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        changePage(delta > 0 ? -1 : 1);
        return true;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        this.renderBackground(g);
        g.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, Ui.GOLD);
        g.fill(px, py, px + pw, py + ph, Ui.BG);
        g.fill(px, py, px + pw, py + 18, Ui.HEADER);
        g.drawString(this.font, Ui.t("picker.title"), px + 8, py + 5, Ui.GOLD_TEXT, false);

        ItemStack hover = ItemStack.EMPTY;
        int per = COLS * ROWS;
        for (int i = 0; i < per; i++) {
            int idx = page * per + i;
            int x = gridX + (i % COLS) * CELL;
            int y = gridY + (i / COLS) * CELL;
            boolean hov = idx < filtered.size() && Ui.inside(mx, my, x, y, CELL, CELL);
            g.fill(x, y, x + CELL - 1, y + CELL - 1, hov ? 0xFF3A3220 : 0xFF0A0A0A);
            if (idx < filtered.size()) {
                ItemStack s = new ItemStack(filtered.get(idx));
                g.renderItem(s, x + 2, y + 2);
                if (hov) hover = s;
            }
        }
        int pagerY = gridY + ROWS * CELL + 4;
        g.drawCenteredString(this.font, Ui.t("picker.page", page + 1, pageCount()), px + pw / 2, pagerY + 4, Ui.TEXT);

        super.render(g, mx, my, pt);
        if (!hover.isEmpty()) g.renderTooltip(this.font, hover, mx, my);
    }
}
