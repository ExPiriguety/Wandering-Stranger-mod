package com.wanderingstranger.client.gui;

import net.minecraft.nbt.TagParser;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

final class Ui {
    static final int BG = 0xF0141218;
    static final int GOLD = 0xFFC9A227;
    static final int HEADER = 0xFF241E10;
    static final int GOLD_TEXT = 0xFFE8C766;
    static final int TEXT = 0xFFE0E0E0;
    static final int DIM = 0xFF8A8A8A;
    static final int SLOT_BORDER = 0xFF5A4A1A;
    static final int ROW_SEL = 0x55C9A227;
    static final int ROW_HOVER = 0x26FFFFFF;

    static Component t(String key, Object... args) {
        return Component.translatable("gui.wandering_stranger." + key, args);
    }

    static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    static ItemStack stack(EditorData.Entry e, String currency) {
        if (e == null) return ItemStack.EMPTY;
        String id = "$currency".equals(e.id) ? currency : e.id;
        ResourceLocation rl = ResourceLocation.tryParse(id);
        Item item = rl == null ? Items.AIR : ForgeRegistries.ITEMS.getValue(rl);
        if (item == null || item == Items.AIR) return new ItemStack(Items.BARRIER);
        ItemStack s = new ItemStack(item, Math.max(1, Math.min(64, e.count)));
        if (e.nbt != null && !e.nbt.isBlank()) {
            try {
                s.setTag(TagParser.parseTag(e.nbt));
            } catch (Exception ignored) {
            }
        }
        return s;
    }

    static String name(EditorData.Entry e, String currency) {
        if (e == null) return "";
        String n = stack(e, currency).getHoverName().getString();
        return "$currency".equals(e.id) ? "* " + n : n;
    }

    private Ui() {}
}
