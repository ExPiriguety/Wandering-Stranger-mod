package com.wanderingstranger.client.gui;

import com.wanderingstranger.network.Net;
import com.wanderingstranger.network.SaveChunkPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/** In-game editor for the Wandering Stranger trades (/stranger editor). */
public class EditorScreen extends Screen {
    private static final int ROW_H = 24;
    private static final Predicate<String> DIGITS = s -> s.matches("\\d{0,4}");
    private static final Predicate<String> DECIMAL = s -> s.matches("\\d{0,2}(\\.\\d{0,3})?");

    private final EditorData data;
    private int tab;          // 0 = common, 1 = special, 2 = settings
    private int selected = -1;
    private int scroll;
    private boolean refreshing;
    private ItemStack hoverStack = ItemStack.EMPTY;

    private int px, py, pw, ph, bodyTop, bodyBottom, listX, listW, rx;
    private int yA, yB, yR, yStats, yBtns;

    private Button tabCommon, tabSpecial, tabConfig, btnNew, btnUp, btnDown, btnDup, btnDel, btnClearB;
    private EditBox countA, countB, countR, maxUses, xp, mult, cfgCommon, cfgSpecial;

    public EditorScreen(EditorData data) {
        super(Ui.t("title"));
        this.data = data;
    }

    // ------------------------------------------------------------------ helpers

    private List<EditorData.Trade> list() {
        return tab == 0 ? data.common : data.special;
    }

    private EditorData.Trade sel() {
        if (tab == 2) return null;
        List<EditorData.Trade> l = list();
        return selected >= 0 && selected < l.size() ? l.get(selected) : null;
    }

    private static int parse(String s, int min, int max, int fallback) {
        try {
            return Math.max(min, Math.min(max, Integer.parseInt(s)));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private EditBox box(int x, int y, int w, Predicate<String> filter, Consumer<String> responder) {
        EditBox e = new EditBox(this.font, x, y, w, 18, Component.empty());
        e.setMaxLength(8);
        e.setFilter(filter);
        e.setResponder(s -> {
            if (!refreshing) responder.accept(s);
        });
        return addRenderableWidget(e);
    }

    // --------------------------------------------------------------------- init

    @Override
    protected void init() {
        pw = Math.min(this.width - 16, 440);
        ph = Math.min(this.height - 12, 272);
        px = (this.width - pw) / 2;
        py = (this.height - ph) / 2;
        bodyTop = py + 48;
        bodyBottom = py + ph - 30;
        listX = px + 8;
        listW = 172;
        rx = px + 190;
        yA = bodyTop + 4;
        yB = yA + 36;
        yR = yB + 36;
        yStats = yR + 38;
        yBtns = yStats + 36;

        tabCommon = addRenderableWidget(Button.builder(Component.empty(), b -> setTab(0))
                .bounds(px + 8, py + 24, 100, 18).build());
        tabSpecial = addRenderableWidget(Button.builder(Component.empty(), b -> setTab(1))
                .bounds(px + 112, py + 24, 100, 18).build());
        tabConfig = addRenderableWidget(Button.builder(Ui.t("tab.config"), b -> setTab(2))
                .bounds(px + 216, py + 24, 100, 18).build());

        btnNew = addRenderableWidget(Button.builder(Ui.t("new"), b -> addTrade())
                .bounds(px + 8, py + ph - 24, 90, 18).build());
        addRenderableWidget(Button.builder(Ui.t("save"), b -> saveAndClose())
                .bounds(px + pw - 8 - 84 - 4 - 110, py + ph - 24, 110, 18).build());
        addRenderableWidget(Button.builder(Ui.t("cancel"), b -> onClose())
                .bounds(px + pw - 8 - 84, py + ph - 24, 84, 18).build());

        countA = box(rx + 28, yA + 11, 34, DIGITS, s -> {
            if (sel() != null) sel().a.count = parse(s, 1, 64, sel().a.count);
        });
        countB = box(rx + 28, yB + 11, 34, DIGITS, s -> {
            if (sel() != null && sel().b != null) sel().b.count = parse(s, 1, 64, sel().b.count);
        });
        countR = box(rx + 28, yR + 11, 34, DIGITS, s -> {
            if (sel() != null) sel().result.count = parse(s, 1, 64, sel().result.count);
        });
        btnClearB = addRenderableWidget(Button.builder(Component.literal("x"), b -> {
            if (sel() != null) {
                sel().b = null;
                refreshFields();
                updateVisibility();
            }
        }).bounds(px + pw - 8 - 18, yB + 11, 18, 18).build());

        maxUses = box(rx, yStats + 12, 44, DIGITS, s -> {
            if (sel() != null) sel().maxUses = parse(s, 1, 9999, sel().maxUses);
        });
        xp = box(rx + 54, yStats + 12, 44, DIGITS, s -> {
            if (sel() != null) sel().xp = parse(s, 0, 9999, sel().xp);
        });
        mult = box(rx + 108, yStats + 12, 54, DECIMAL, s -> {
            if (sel() == null) return;
            try {
                sel().mult = Math.max(0F, Math.min(10F, Float.parseFloat(s)));
            } catch (NumberFormatException ignored) {
            }
        });

        btnUp = addRenderableWidget(Button.builder(Ui.t("up"), b -> move(-1)).bounds(rx, yBtns, 56, 18).build());
        btnDown = addRenderableWidget(Button.builder(Ui.t("down"), b -> move(1)).bounds(rx + 60, yBtns, 56, 18).build());
        btnDup = addRenderableWidget(Button.builder(Ui.t("duplicate"), b -> duplicate()).bounds(rx + 120, yBtns, 62, 18).build());
        btnDel = addRenderableWidget(Button.builder(Ui.t("delete"), b -> delete()).bounds(rx + 186, yBtns, 56, 18).build());

        cfgCommon = box(px + 20 + 150, bodyTop + 66, 44, DIGITS, s -> data.commonCount = parse(s, 0, 32, data.commonCount));
        cfgSpecial = box(px + 20 + 150, bodyTop + 92, 44, DIGITS, s -> data.specialCount = parse(s, 0, 32, data.specialCount));

        refreshFields();
        updateVisibility();
    }

    private void setTab(int t) {
        tab = t;
        selected = -1;
        scroll = 0;
        this.setFocused(null);
        refreshFields();
        updateVisibility();
    }

    private void refreshFields() {
        refreshing = true;
        EditorData.Trade t = sel();
        if (t != null) {
            countA.setValue(String.valueOf(t.a.count));
            countB.setValue(t.b == null ? "" : String.valueOf(t.b.count));
            countR.setValue(String.valueOf(t.result.count));
            maxUses.setValue(String.valueOf(t.maxUses));
            xp.setValue(String.valueOf(t.xp));
            mult.setValue(String.valueOf(t.mult));
        }
        cfgCommon.setValue(String.valueOf(data.commonCount));
        cfgSpecial.setValue(String.valueOf(data.specialCount));
        refreshing = false;
        tabCommon.setMessage(Ui.t("tab.common", data.common.size()));
        tabSpecial.setMessage(Ui.t("tab.special", data.special.size()));
    }

    private void updateVisibility() {
        EditorData.Trade t = sel();
        boolean listTab = tab != 2;
        boolean edit = listTab && t != null;
        boolean hasB = edit && t.b != null;
        btnNew.visible = listTab;
        countA.visible = edit;
        countB.visible = hasB;
        countR.visible = edit;
        btnClearB.visible = hasB;
        maxUses.visible = edit;
        xp.visible = edit;
        mult.visible = edit;
        btnUp.visible = edit;
        btnDown.visible = edit;
        btnDup.visible = edit;
        btnDel.visible = edit;
        cfgCommon.visible = tab == 2;
        cfgSpecial.visible = tab == 2;
        tabCommon.active = tab != 0;
        tabSpecial.active = tab != 1;
        tabConfig.active = tab != 2;
    }

    // ------------------------------------------------------------------ actions

    private void addTrade() {
        list().add(new EditorData.Trade());
        selected = list().size() - 1;
        scrollToSelected();
        refreshFields();
        updateVisibility();
    }

    private void duplicate() {
        EditorData.Trade t = sel();
        if (t == null) return;
        list().add(selected + 1, t.copy());
        selected++;
        scrollToSelected();
        refreshFields();
        updateVisibility();
    }

    private void delete() {
        if (sel() == null) return;
        list().remove(selected);
        selected = Math.min(selected, list().size() - 1);
        refreshFields();
        updateVisibility();
    }

    private void move(int d) {
        int target = selected + d;
        if (sel() == null || target < 0 || target >= list().size()) return;
        EditorData.Trade t = list().remove(selected);
        list().add(target, t);
        selected = target;
        scrollToSelected();
    }

    private void scrollToSelected() {
        int top = selected * ROW_H;
        int view = bodyBottom - bodyTop;
        if (top < scroll) scroll = top;
        if (top + ROW_H > scroll + view) scroll = top + ROW_H - view;
        clampScroll();
    }

    private void clampScroll() {
        int max = Math.max(0, list().size() * ROW_H - (bodyBottom - bodyTop));
        scroll = Math.max(0, Math.min(max, scroll));
    }

    private void openPicker(boolean allowClear, boolean allowCurrency, Consumer<EditorData.Entry> cb) {
        Minecraft.getInstance().setScreen(new ItemPickerScreen(this, data.currency, allowClear, allowCurrency, cb));
    }

    private void pickA() {
        EditorData.Trade t = sel();
        if (t == null) return;
        openPicker(false, true, e -> {
            if (e != null) {
                e.count = t.a.count;
                t.a = e;
            }
        });
    }

    private void pickB() {
        EditorData.Trade t = sel();
        if (t == null) return;
        openPicker(true, true, e -> {
            if (e == null) {
                t.b = null;
            } else {
                e.count = t.b == null ? 1 : t.b.count;
                t.b = e;
            }
        });
    }

    private void pickR() {
        EditorData.Trade t = sel();
        if (t == null) return;
        openPicker(false, true, e -> {
            if (e != null) {
                e.count = t.result.count;
                t.result = e;
            }
        });
    }

    private void pickCurrency() {
        openPicker(false, false, e -> {
            if (e != null) data.currency = e.id;
        });
    }

    private void saveAndClose() {
        String json = data.toJson();
        int size = 8000;
        int total = Math.max(1, (json.length() + size - 1) / size);
        for (int i = 0; i < total; i++) {
            String part = json.substring(i * size, Math.min(json.length(), (i + 1) * size));
            Net.CHANNEL.sendToServer(new SaveChunkPacket(i, total, part));
        }
        onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // -------------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (button != 0) return false;
        if (tab == 2) {
            if (Ui.inside(mx, my, px + 20, bodyTop + 22, 20, 20)) {
                pickCurrency();
                return true;
            }
            return false;
        }
        if (mx >= listX && mx < listX + listW && my >= bodyTop && my < bodyBottom) {
            int idx = (int) ((my - bodyTop + scroll) / ROW_H);
            if (idx >= 0 && idx < list().size()) {
                selected = idx;
                this.setFocused(null);
                refreshFields();
                updateVisibility();
                return true;
            }
        }
        EditorData.Trade t = sel();
        if (t != null) {
            if (Ui.inside(mx, my, rx, yA + 11, 20, 20)) {
                pickA();
                return true;
            }
            if (Ui.inside(mx, my, rx, yB + 11, 20, 20)) {
                pickB();
                return true;
            }
            if (Ui.inside(mx, my, rx, yR + 11, 20, 20)) {
                pickR();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (tab != 2 && mx >= listX && mx < listX + listW) {
            scroll -= (int) (delta * ROW_H);
            clampScroll();
            return true;
        }
        return super.mouseScrolled(mx, my, delta);
    }

    // ---------------------------------------------------------------- rendering

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        hoverStack = ItemStack.EMPTY;
        this.renderBackground(g);
        g.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, Ui.GOLD);
        g.fill(px, py, px + pw, py + ph, Ui.BG);
        g.fill(px, py, px + pw, py + 18, Ui.HEADER);
        g.drawString(this.font, this.title, px + 8, py + 5, Ui.GOLD_TEXT, false);
        g.fill(px + 8, py + 44, px + pw - 8, py + 45, Ui.SLOT_BORDER);

        if (tab == 2) {
            renderConfig(g, mx, my);
        } else {
            renderList(g, mx, my);
            g.fill(px + 184, bodyTop, px + 185, bodyBottom, Ui.SLOT_BORDER);
            renderEditPanel(g, mx, my);
        }

        super.render(g, mx, my, pt);
        if (!hoverStack.isEmpty()) g.renderTooltip(this.font, hoverStack, mx, my);
    }

    private void renderList(GuiGraphics g, int mx, int my) {
        List<EditorData.Trade> l = list();
        g.enableScissor(listX, bodyTop, listX + listW, bodyBottom);
        for (int i = 0; i < l.size(); i++) {
            int y = bodyTop + i * ROW_H - scroll;
            if (y + ROW_H < bodyTop || y > bodyBottom) continue;
            EditorData.Trade t = l.get(i);
            boolean hov = Ui.inside(mx, my, listX, y, listW - 6, ROW_H - 2)
                    && my >= bodyTop && my < bodyBottom;
            if (i == selected) g.fill(listX, y, listX + listW - 6, y + ROW_H - 2, Ui.ROW_SEL);
            else if (hov) g.fill(listX, y, listX + listW - 6, y + ROW_H - 2, Ui.ROW_HOVER);

            ItemStack sa = Ui.stack(t.a, data.currency);
            g.renderItem(sa, listX + 3, y + 3);
            g.renderItemDecorations(this.font, sa, listX + 3, y + 3);
            if (t.b != null) {
                ItemStack sb = Ui.stack(t.b, data.currency);
                g.renderItem(sb, listX + 21, y + 3);
                g.renderItemDecorations(this.font, sb, listX + 21, y + 3);
            }
            g.drawString(this.font, "\u2192", listX + 40, y + 8, Ui.DIM, false);
            ItemStack sr = Ui.stack(t.result, data.currency);
            g.renderItem(sr, listX + 52, y + 3);
            g.renderItemDecorations(this.font, sr, listX + 52, y + 3);
            g.drawString(this.font, this.font.plainSubstrByWidth(Ui.name(t.result, data.currency), 90),
                    listX + 72, y + 8, Ui.TEXT, false);
        }
        g.disableScissor();

        int max = Math.max(0, l.size() * ROW_H - (bodyBottom - bodyTop));
        if (max > 0) {
            int view = bodyBottom - bodyTop;
            int barH = Math.max(12, view * view / (view + max));
            int barY = bodyTop + (view - barH) * scroll / max;
            g.fill(listX + listW - 3, barY, listX + listW - 1, barY + barH, Ui.GOLD);
        }
        if (l.isEmpty()) {
            g.drawString(this.font, Ui.t("hint_empty"), listX + 4, bodyTop + 8, Ui.DIM, false);
        }
    }

    private void renderEditPanel(GuiGraphics g, int mx, int my) {
        EditorData.Trade t = sel();
        if (t == null) {
            g.drawString(this.font, Ui.t("hint_select"), rx, bodyTop + 8, Ui.DIM, false);
            return;
        }
        g.drawString(this.font, Ui.t("pay1"), rx, yA, Ui.GOLD_TEXT, false);
        drawSlot(g, rx, yA + 11, t.a, mx, my);
        g.drawString(this.font, this.font.plainSubstrByWidth(Ui.name(t.a, data.currency), 120),
                rx + 68, yA + 16, Ui.TEXT, false);

        g.drawString(this.font, Ui.t("pay2"), rx, yB, Ui.GOLD_TEXT, false);
        drawSlot(g, rx, yB + 11, t.b, mx, my);
        if (t.b != null) {
            g.drawString(this.font, this.font.plainSubstrByWidth(Ui.name(t.b, data.currency), 120),
                    rx + 68, yB + 16, Ui.TEXT, false);
        }

        g.drawString(this.font, Ui.t("receive"), rx, yR, Ui.GOLD_TEXT, false);
        drawSlot(g, rx, yR + 11, t.result, mx, my);
        g.drawString(this.font, this.font.plainSubstrByWidth(Ui.name(t.result, data.currency), 120),
                rx + 68, yR + 16, Ui.TEXT, false);

        g.drawString(this.font, Ui.t("max_uses"), rx, yStats, Ui.GOLD_TEXT, false);
        g.drawString(this.font, Ui.t("xp"), rx + 54, yStats, Ui.GOLD_TEXT, false);
        g.drawString(this.font, Ui.t("multiplier"), rx + 108, yStats, Ui.GOLD_TEXT, false);
    }

    private void renderConfig(GuiGraphics g, int mx, int my) {
        int x = px + 20;
        g.drawString(this.font, Ui.t("currency"), x, bodyTop + 6, Ui.GOLD_TEXT, false);
        EditorData.Entry cur = new EditorData.Entry(data.currency, 1, null);
        drawSlot(g, x, bodyTop + 22, cur, mx, my);
        g.drawString(this.font, this.font.plainSubstrByWidth(Ui.name(cur, data.currency), 200),
                x + 28, bodyTop + 28, Ui.TEXT, false);
        g.drawString(this.font, Ui.t("currency_help"), x, bodyTop + 46, Ui.DIM, false);
        g.drawString(this.font, Ui.t("common_per"), x, bodyTop + 71, Ui.TEXT, false);
        g.drawString(this.font, Ui.t("special_per"), x, bodyTop + 97, Ui.TEXT, false);
    }

    private void drawSlot(GuiGraphics g, int x, int y, EditorData.Entry e, int mx, int my) {
        boolean hov = Ui.inside(mx, my, x, y, 20, 20);
        g.fill(x - 1, y - 1, x + 21, y + 21, hov ? Ui.GOLD : Ui.SLOT_BORDER);
        g.fill(x, y, x + 20, y + 20, 0xFF000000);
        if (e != null) {
            ItemStack s = Ui.stack(e, data.currency);
            g.renderItem(s, x + 2, y + 2);
            g.renderItemDecorations(this.font, s, x + 2, y + 2);
            if (hov) hoverStack = s;
        } else {
            g.drawCenteredString(this.font, "+", x + 10, y + 6, Ui.DIM);
        }
    }
}
