package com.wanderingstranger.trades;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import com.wanderingstranger.WanderingStrangerMod;
import com.wanderingstranger.spawn.SpawnSettings;
import net.minecraft.nbt.TagParser;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Loads config/wandering_stranger/trades.json (trades + settings).
 * - Created only when missing. Only rewritten when an OP saves from the in-game editor
 *   (a trades.json.bak backup is made first).
 * - If the file is broken, the previously loaded data is kept.
 */
public final class StrangerTrades {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    public record Result(boolean ok, String message) {}

    private static volatile List<JsonObject> common = List.of();
    private static volatile List<JsonObject> special = List.of();
    private static volatile JsonObject lastRoot = new JsonObject();
    private static volatile String currency = "minecraft:emerald";
    private static volatile int commonCount = 5;
    private static volatile int specialCount = 1;

    public static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve(WanderingStrangerMod.MOD_ID).resolve("trades.json");
    }

    public static int commonSize() {
        return common.size();
    }

    public static int specialSize() {
        return special.size();
    }

    /** JSON of the last successfully loaded file (sent to the editor). */
    public static String currentJson() {
        return GSON.toJson(lastRoot);
    }

    public static synchronized Result reload() {
        Path path = file();
        try {
            if (Files.notExists(path)) {
                Files.createDirectories(path.getParent());
                try (InputStream in = StrangerTrades.class.getResourceAsStream("/default_trades.json")) {
                    if (in == null) throw new IOException("default_trades.json missing from the mod jar");
                    Files.copy(in, path);
                }
                LOGGER.info("Created default trades file at {}", path);
            }
            JsonObject root;
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                root = JsonParser.parseReader(reader).getAsJsonObject();
            }
            JsonObject settings = root.has("settings") && root.get("settings").isJsonObject()
                    ? root.getAsJsonObject("settings") : new JsonObject();
            currency = settings.has("currency") ? settings.get("currency").getAsString() : "minecraft:emerald";
            commonCount = settings.has("common_offers") ? Mth.clamp(settings.get("common_offers").getAsInt(), 0, 32) : 5;
            specialCount = settings.has("special_offers") ? Mth.clamp(settings.get("special_offers").getAsInt(), 0, 32) : 1;

            SpawnSettings.load(root);
            List<JsonObject> newCommon = readPool(root, "common");
            List<JsonObject> newSpecial = readPool(root, "special");
            common = newCommon;
            special = newSpecial;
            lastRoot = root;
            String msg = "Wandering Stranger trades loaded: " + newCommon.size() + " common, "
                    + newSpecial.size() + " special.";
            LOGGER.info(msg);
            return new Result(true, msg);
        } catch (Exception e) {
            LOGGER.error("Could not read {}. Keeping the previously loaded trades; the file was NOT modified.", path, e);
            return new Result(false, "Failed to read trades.json (kept previous trades): " + e.getMessage());
        }
    }

    /** Called by the server when an OP saves from the in-game editor. */
    public static synchronized Result saveFromEditor(String json) {
        try {
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();
            Path path = file();
            Files.createDirectories(path.getParent());
            if (Files.exists(path)) {
                Files.copy(path, path.resolveSibling("trades.json.bak"), StandardCopyOption.REPLACE_EXISTING);
            }
            Path tmp = path.resolveSibling("trades.json.tmp");
            Files.writeString(tmp, GSON.toJson(root), StandardCharsets.UTF_8);
            try {
                Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING);
            }
            return reload();
        } catch (Exception e) {
            LOGGER.error("Could not save trades from the editor", e);
            return new Result(false, "Could not save trades: " + e.getMessage());
        }
    }

    private static List<JsonObject> readPool(JsonObject root, String key) {
        List<JsonObject> out = new ArrayList<>();
        if (!root.has(key) || !root.get(key).isJsonArray()) return out;
        JsonArray arr = root.getAsJsonArray(key);
        for (int i = 0; i < arr.size(); i++) {
            JsonElement el = arr.get(i);
            try {
                if (!el.isJsonObject()) throw new IllegalArgumentException("not an object");
                buildOffer(el.getAsJsonObject()); // validation only
                out.add(el.getAsJsonObject());
            } catch (Exception e) {
                LOGGER.warn("Skipping invalid trade {}[{}]: {}", key, i, e.getMessage());
            }
        }
        return out;
    }

    /** Adds random offers to the given list. Returns how many were added. */
    public static int fillOffers(MerchantOffers target, RandomSource random) {
        int before = target.size();
        pick(target, common, commonCount, random);
        pick(target, special, specialCount, random);
        return target.size() - before;
    }

    private static void pick(MerchantOffers target, List<JsonObject> pool, int count, RandomSource random) {
        if (pool.isEmpty() || count <= 0) return;
        List<JsonObject> shuffled = new ArrayList<>(pool);
        Collections.shuffle(shuffled, new java.util.Random(random.nextLong()));
        int added = 0;
        for (JsonObject def : shuffled) {
            if (added >= count) break;
            try {
                target.add(buildOffer(def));
                added++;
            } catch (Exception e) {
                LOGGER.warn("Skipping trade at spawn time: {}", e.getMessage());
            }
        }
    }

    private static MerchantOffer buildOffer(JsonObject def) throws Exception {
        JsonArray give = def.getAsJsonArray("give");
        if (give == null || give.size() < 1 || give.size() > 2) {
            throw new IllegalArgumentException("'give' must have 1 or 2 items");
        }
        ItemStack costA = readStack(give.get(0).getAsJsonObject());
        ItemStack costB = give.size() > 1 ? readStack(give.get(1).getAsJsonObject()) : ItemStack.EMPTY;
        ItemStack result = readStack(def.getAsJsonObject("get"));
        int maxUses = def.has("max_uses") ? Math.max(1, def.get("max_uses").getAsInt()) : 12;
        int xp = def.has("xp") ? Math.max(0, def.get("xp").getAsInt()) : 1;
        float mult = def.has("price_multiplier") ? def.get("price_multiplier").getAsFloat() : 0.05F;
        return new MerchantOffer(costA, costB, result, maxUses, xp, mult);
    }

    private static ItemStack readStack(JsonObject o) throws Exception {
        if (o == null || !o.has("item")) throw new IllegalArgumentException("missing 'item'");
        String id = o.get("item").getAsString();
        if (id.equals("$currency")) id = currencyId();
        Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(id));
        if (item == null || item == Items.AIR) throw new IllegalArgumentException("unknown item '" + id + "'");
        int count = o.has("count") ? o.get("count").getAsInt() : 1;
        ItemStack stack = new ItemStack(item, Mth.clamp(count, 1, 64));
        if (o.has("nbt")) stack.setTag(TagParser.parseTag(o.get("nbt").getAsString()));
        return stack;
    }

    private static String currencyId() {
        String id = currency;
        try {
            Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(id));
            if (item != null && item != Items.AIR) return id;
        } catch (Exception ignored) {
        }
        LOGGER.warn("currency '{}' does not exist; using minecraft:emerald instead.", id);
        return "minecraft:emerald";
    }

    private StrangerTrades() {}
}
