package com.wanderingstranger.command;

import com.mojang.brigadier.CommandDispatcher;
import com.wanderingstranger.ModEntities;
import com.wanderingstranger.StrangerEntity;
import com.wanderingstranger.network.Net;
import com.wanderingstranger.network.OpenEditorPacket;
import com.wanderingstranger.spawn.SpawnSettings;
import com.wanderingstranger.spawn.StrangerSpawner;
import com.wanderingstranger.trades.StrangerTrades;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

public final class StrangerCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("stranger")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("summon")
                        .executes(ctx -> {
                            Vec3 p = ctx.getSource().getPosition();
                            return summon(ctx.getSource(), BlockPos.containing(p.x, p.y, p.z));
                        })
                        .then(Commands.argument("pos", BlockPosArgument.blockPos())
                                .executes(ctx -> summon(ctx.getSource(), BlockPosArgument.getBlockPos(ctx, "pos")))))
                .then(Commands.literal("editor")
                        .executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                            Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                                    new OpenEditorPacket(StrangerTrades.currentJson()));
                            return 1;
                        }))
                .then(Commands.literal("reload").executes(ctx -> reload(ctx.getSource())))
                .then(Commands.literal("status").executes(ctx -> status(ctx.getSource())))
                .then(Commands.literal("roll").executes(ctx -> run(ctx.getSource(), StrangerSpawner.Mode.ROLL)))
                .then(Commands.literal("force").executes(ctx -> run(ctx.getSource(), StrangerSpawner.Mode.FORCE)))
                .then(Commands.literal("reset").executes(ctx -> reset(ctx.getSource()))));
    }

    private static int summon(CommandSourceStack source, BlockPos pos) {
        ServerLevel level = source.getLevel();
        StrangerEntity stranger = ModEntities.STRANGER.get().spawn(level, pos, MobSpawnType.COMMAND);
        if (stranger == null) {
            source.sendFailure(Component.translatable("command.wandering_stranger.summon_failed"));
            return 0;
        }
        stranger.setPersistenceRequired();
        source.sendSuccess(() -> Component.translatable("command.wandering_stranger.summoned",
                pos.getX(), pos.getY(), pos.getZ()), true);
        return 1;
    }

    private static int reload(CommandSourceStack source) {
        StrangerTrades.Result result = StrangerTrades.reload();
        if (result.ok()) {
            StrangerSpawner.applyVanillaMode(source.getServer());
            source.sendSuccess(() -> Component.translatable("command.wandering_stranger.reloaded",
                    StrangerTrades.commonSize(), StrangerTrades.specialSize()), true);
            return 1;
        }
        source.sendFailure(Component.translatable("command.wandering_stranger.reload_failed", result.message()));
        return 0;
    }

    private static int status(CommandSourceStack source) {
        for (Component line : StrangerSpawner.status(source.getServer())) {
            source.sendSuccess(() -> line, false);
        }
        return 1;
    }

    private static int run(CommandSourceStack source, StrangerSpawner.Mode mode) {
        StrangerSpawner.Report report = StrangerSpawner.attempt(source.getServer(), mode);
        if (report.ok()) {
            // The public chat announcement already tells everyone; only confirm when it is turned off.
            if (!SpawnSettings.announceSpawn) {
                source.sendSuccess(report::message, true);
            }
            return 1;
        }
        source.sendFailure(report.message());
        return 0;
    }

    private static int reset(CommandSourceStack source) {
        StrangerSpawner.data(source.getServer()).reset();
        source.sendSuccess(() -> Component.translatable("command.wandering_stranger.reset"), true);
        return 1;
    }

    private StrangerCommand() {}
}
