package com.wanderingstranger.network;

import com.wanderingstranger.spawn.StrangerSpawner;
import com.wanderingstranger.trades.StrangerTrades;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Client -> server: the edited JSON, split in small chunks (serverbound packets are limited to ~32 KB).
 * Only players with permission level 2 (OP) are accepted.
 */
public class SaveChunkPacket {
    private static final Map<UUID, StringBuilder> BUFFERS = new HashMap<>();
    private static final int MAX_CHUNKS = 400;

    private final int index;
    private final int total;
    private final String part;

    public SaveChunkPacket(int index, int total, String part) {
        this.index = index;
        this.total = total;
        this.part = part;
    }

    public static void encode(SaveChunkPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.index);
        buf.writeVarInt(msg.total);
        buf.writeUtf(msg.part, 32000);
    }

    public static SaveChunkPacket decode(FriendlyByteBuf buf) {
        return new SaveChunkPacket(buf.readVarInt(), buf.readVarInt(), buf.readUtf(32000));
    }

    public static void handle(SaveChunkPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        ctx.get().enqueueWork(() -> {
            if (player == null || !player.hasPermissions(2)) return;
            if (msg.total <= 0 || msg.total > MAX_CHUNKS || msg.index < 0 || msg.index >= msg.total) return;
            synchronized (BUFFERS) {
                StringBuilder sb = BUFFERS.get(player.getUUID());
                if (msg.index == 0 || sb == null) {
                    sb = new StringBuilder();
                    BUFFERS.put(player.getUUID(), sb);
                }
                sb.append(msg.part);
                if (msg.index == msg.total - 1) {
                    BUFFERS.remove(player.getUUID());
                    StrangerTrades.Result result = StrangerTrades.saveFromEditor(sb.toString());
                    if (result.ok()) {
                        StrangerSpawner.applyVanillaMode(player.getServer());
                        player.sendSystemMessage(Component.translatable("command.wandering_stranger.saved",
                                StrangerTrades.commonSize(), StrangerTrades.specialSize()));
                    } else {
                        player.sendSystemMessage(Component.translatable("command.wandering_stranger.save_failed",
                                result.message()));
                    }
                }
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
