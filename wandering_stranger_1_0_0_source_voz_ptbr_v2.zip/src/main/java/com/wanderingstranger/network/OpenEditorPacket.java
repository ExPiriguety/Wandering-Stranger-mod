package com.wanderingstranger.network;

import com.wanderingstranger.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: opens the editor with the current trades JSON. */
public class OpenEditorPacket {
    private static final int MAX = 1_000_000;
    private final String json;

    public OpenEditorPacket(String json) {
        this.json = json;
    }

    public static void encode(OpenEditorPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.json, MAX);
    }

    public static OpenEditorPacket decode(FriendlyByteBuf buf) {
        return new OpenEditorPacket(buf.readUtf(MAX));
    }

    public static void handle(OpenEditorPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openEditor(msg.json)));
        ctx.get().setPacketHandled(true);
    }
}
