package com.wanderingstranger;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, WanderingStrangerMod.MOD_ID);

    public static final RegistryObject<SoundEvent> AMBIENT = reg("entity.stranger.ambient");
    public static final RegistryObject<SoundEvent> TRADE = reg("entity.stranger.trade");
    public static final RegistryObject<SoundEvent> YES = reg("entity.stranger.yes");
    public static final RegistryObject<SoundEvent> NO = reg("entity.stranger.no");
    public static final RegistryObject<SoundEvent> HURT = reg("entity.stranger.hurt");
    public static final RegistryObject<SoundEvent> DEATH = reg("entity.stranger.death");
    public static final RegistryObject<SoundEvent> DRINK_MILK = reg("entity.stranger.drink_milk");
    public static final RegistryObject<SoundEvent> DRINK_POTION = reg("entity.stranger.drink_potion");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                new ResourceLocation(WanderingStrangerMod.MOD_ID, name)));
    }

    private ModSounds() {}
}
