package com.wanderingstranger.spawn;

import com.google.gson.JsonObject;

/** The "spawn" block of config/wandering_stranger/trades.json. Missing keys use the defaults below. */
public final class SpawnSettings {
    public static volatile boolean enabled = true;
    public static volatile int firstSpawnDay = 5;
    public static volatile boolean firstSpawnGuaranteed = true;
    public static volatile int spawnTime = 6000;          // ticks of the day (6000 = noon)
    public static volatile int windowTicks = 6000;        // how long after spawnTime the spawn may still happen
    public static volatile int initialChance = 25;
    public static volatile int chanceStep = 25;
    public static volatile int stayTicks = 4800;          // 4 minutes
    public static volatile int minDistance = 20;
    public static volatile int maxDistance = 40;
    public static volatile int minDaysBetween = 1;
    public static volatile boolean onlyOneAtATime = true;
    public static volatile boolean waitIfTrading = true;
    public static volatile boolean announceSpawn = true;
    public static volatile boolean announceLeave = true;
    public static volatile String spawnMessage = "";      // empty = translated default; supports {player}
    public static volatile String leaveMessage = "";
    public static volatile String vanillaTrader = "remove"; // allow | block | remove

    public static void load(JsonObject root) {
        JsonObject s = root.has("spawn") && root.get("spawn").isJsonObject()
                ? root.getAsJsonObject("spawn") : new JsonObject();
        enabled = bool(s, "enabled", true);
        firstSpawnDay = num(s, "first_spawn_day", 5, 1, 1_000_000);
        firstSpawnGuaranteed = bool(s, "first_spawn_guaranteed", true);
        spawnTime = num(s, "spawn_time", 6000, 0, 23999);
        windowTicks = num(s, "spawn_window_ticks", 6000, 20, 24000);
        initialChance = num(s, "initial_chance", 25, 0, 100);
        chanceStep = num(s, "chance_step", 25, 0, 100);
        stayTicks = num(s, "stay_ticks", 4800, 100, 24000 * 30);
        minDistance = num(s, "min_distance", 20, 4, 120);
        maxDistance = Math.max(minDistance + 1, num(s, "max_distance", 40, 5, 128));
        minDaysBetween = num(s, "min_days_between", 1, 0, 1000);
        onlyOneAtATime = bool(s, "only_one_at_a_time", true);
        waitIfTrading = bool(s, "wait_if_trading", true);
        announceSpawn = bool(s, "announce_spawn", true);
        announceLeave = bool(s, "announce_leave", true);
        spawnMessage = str(s, "spawn_message", "");
        leaveMessage = str(s, "leave_message", "");
        String v = str(s, "vanilla_trader", "remove").toLowerCase(java.util.Locale.ROOT);
        vanillaTrader = (v.equals("allow") || v.equals("block") || v.equals("remove")) ? v : "remove";
    }

    private static boolean bool(JsonObject o, String k, boolean def) {
        try {
            return o.has(k) ? o.get(k).getAsBoolean() : def;
        } catch (Exception e) {
            return def;
        }
    }

    private static int num(JsonObject o, String k, int def, int min, int max) {
        try {
            return o.has(k) ? Math.max(min, Math.min(max, o.get(k).getAsInt())) : def;
        } catch (Exception e) {
            return def;
        }
    }

    private static String str(JsonObject o, String k, String def) {
        try {
            return o.has(k) ? o.get(k).getAsString() : def;
        } catch (Exception e) {
            return def;
        }
    }

    private SpawnSettings() {}
}
