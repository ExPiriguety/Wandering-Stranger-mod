package com.wanderingstranger.spawn;

import com.wanderingstranger.ModEntities;
import com.wanderingstranger.StrangerEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Natural spawning of the Wandering Stranger (rules come from SpawnSettings, state from StrangerSpawnData). */
public final class StrangerSpawner {
    public enum Mode { NATURAL, ROLL, FORCE }

    public record Report(boolean ok, Component message) {}

    private static final String DATA_ID = "wandering_stranger_spawn";

    public static StrangerSpawnData data(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(StrangerSpawnData::load, StrangerSpawnData::new, DATA_ID);
    }

    public static long day(ServerLevel overworld) {
        return overworld.getDayTime() / 24000L + 1L;
    }

    public static int chanceFor(StrangerSpawnData d) {
        if (!d.everSpawned && SpawnSettings.firstSpawnGuaranteed) return 100;
        long v = (long) SpawnSettings.initialChance + (long) SpawnSettings.chanceStep * d.missedDays;
        return (int) Math.min(100L, v);
    }

    /** Called once per second for the overworld. */
    public static void tick(ServerLevel level) {
        if (!SpawnSettings.enabled) return;
        MinecraftServer server = level.getServer();
        StrangerSpawnData d = data(server);
        long now = level.getGameTime();
        if (d.present && now > d.leaveAt + 6000L) {
            d.present = false;
            d.uuid = null;
            d.setDirty();
        }
        long day = day(level);
        if (d.lastRollDay > day) {
            d.lastRollDay = day - 1;
            d.setDirty();
        }
        long tod = level.getDayTime() % 24000L;
        if (tod < SpawnSettings.spawnTime || tod >= SpawnSettings.spawnTime + SpawnSettings.windowTicks) return;
        if (d.pendingDay == day || d.lastRollDay < day) {
            attempt(server, Mode.NATURAL);
        }
    }

    public static Report attempt(MinecraftServer server, Mode mode) {
        ServerLevel level = server.overworld();
        StrangerSpawnData d = data(server);
        long day = day(level);

        if (mode == Mode.NATURAL && day < SpawnSettings.firstSpawnDay) {
            return new Report(false, Component.translatable("command.wandering_stranger.too_early", SpawnSettings.firstSpawnDay));
        }
        if (mode != Mode.FORCE && d.present && SpawnSettings.onlyOneAtATime) {
            return new Report(false, Component.translatable("command.wandering_stranger.already_present"));
        }
        if (mode == Mode.NATURAL && d.pendingDay != day && d.lastSpawnDay >= 0
                && day - d.lastSpawnDay < SpawnSettings.minDaysBetween) {
            d.lastRollDay = day;
            d.setDirty();
            return new Report(false, Component.translatable("command.wandering_stranger.too_soon"));
        }

        List<ServerPlayer> candidates = new ArrayList<>();
        for (ServerPlayer p : level.players()) {
            if (p.isAlive() && !p.isSpectator()) candidates.add(p);
        }
        if (candidates.isEmpty()) {
            return new Report(false, Component.translatable("command.wandering_stranger.no_players"));
        }

        int chance = chanceFor(d);
        boolean dice;
        if (mode == Mode.FORCE || d.pendingDay == day) {
            dice = true;
        } else {
            dice = level.random.nextInt(100) < chance;
        }
        if (!dice) {
            if (mode == Mode.NATURAL) {
                d.missedDays++;
                d.lastRollDay = day;
                d.setDirty();
            }
            return new Report(false, Component.translatable("command.wandering_stranger.roll_failed", chance));
        }

        ServerPlayer target = candidates.get(level.random.nextInt(candidates.size()));
        StrangerEntity stranger = spawnNear(level, target);
        if (stranger == null) {
            if (mode == Mode.NATURAL) {
                d.pendingDay = day;
                d.lastRollDay = day;
                d.setDirty();
            }
            return new Report(false, Component.translatable("command.wandering_stranger.no_spot"));
        }

        long leaveAt = level.getGameTime() + SpawnSettings.stayTicks;
        stranger.setLeaveAt(leaveAt);
        d.everSpawned = true;
        d.missedDays = 0;
        d.lastSpawnDay = day;
        d.lastRollDay = day;
        d.pendingDay = -1;
        d.present = true;
        d.uuid = stranger.getUUID();
        d.leaveAt = leaveAt;
        d.setDirty();

        announceArrival(server, target);
        return new Report(true, Component.translatable("command.wandering_stranger.spawned", target.getDisplayName()));
    }

    // ------------------------------------------------------------------ location

    private static StrangerEntity spawnNear(ServerLevel level, ServerPlayer player) {
        RandomSource r = level.random;
        EntityType<StrangerEntity> type = ModEntities.STRANGER.get();
        int min = SpawnSettings.minDistance;
        int max = Math.max(min + 1, SpawnSettings.maxDistance);
        int py = player.blockPosition().getY();
        for (int attempt = 0; attempt < 40; attempt++) {
            double ang = r.nextDouble() * Math.PI * 2.0;
            double dist = min + r.nextDouble() * (max - min);
            int x = Mth.floor(player.getX() + Math.cos(ang) * dist);
            int z = Mth.floor(player.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunk(x >> 4, z >> 4)) continue;
            for (int k = 0; k < 28; k++) {
                int dy = (k % 2 == 0) ? k / 2 : -((k + 1) / 2);
                BlockPos pos = new BlockPos(x, py + dy, z);
                if (!level.isInWorldBounds(pos)) continue;
                if (isStandable(level, pos, type)) {
                    StrangerEntity e = type.spawn(level, pos, MobSpawnType.EVENT);
                    if (e != null) {
                        e.setPersistenceRequired();
                        return e;
                    }
                }
            }
        }
        return null;
    }

    private static boolean isStandable(ServerLevel level, BlockPos pos, EntityType<StrangerEntity> type) {
        BlockPos below = pos.below();
        BlockState bs = level.getBlockState(below);
        if (!bs.isFaceSturdy(level, below, Direction.UP)) return false;
        if (!level.getFluidState(pos).isEmpty() || !level.getFluidState(below).isEmpty()) return false;
        return level.noCollision(type.getAABB(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5));
    }

    // ----------------------------------------------------------------- messages

    private static void announceArrival(MinecraftServer server, ServerPlayer target) {
        if (!SpawnSettings.announceSpawn) return;
        String custom = SpawnSettings.spawnMessage;
        Component msg = custom == null || custom.isBlank()
                ? Component.translatable("message.wandering_stranger.arrived", target.getDisplayName())
                : Component.literal(custom.replace("{player}", target.getGameProfile().getName()));
        server.getPlayerList().broadcastSystemMessage(msg, false);
    }

    public static void announceLeave(MinecraftServer server) {
        if (!SpawnSettings.announceLeave) return;
        String custom = SpawnSettings.leaveMessage;
        Component msg = custom == null || custom.isBlank()
                ? Component.translatable("message.wandering_stranger.left")
                : Component.literal(custom);
        server.getPlayerList().broadcastSystemMessage(msg, false);
    }

    /** The tracked stranger left or died: allow the next cycle. */
    public static void notifyGone(MinecraftServer server, UUID uuid) {
        StrangerSpawnData d = data(server);
        if (d.present && uuid != null && uuid.equals(d.uuid)) {
            d.present = false;
            d.uuid = null;
            d.setDirty();
        }
    }

    // ---------------------------------------------------------- vanilla trader

    /** "block" and "remove" turn off the vanilla trader spawner; "remove" also cancels vanilla traders joining the world. */
    public static void applyVanillaMode(MinecraftServer server) {
        String mode = SpawnSettings.vanillaTrader;
        if (mode.equals("block") || mode.equals("remove")) {
            server.getGameRules().getRule(GameRules.RULE_DO_TRADER_SPAWNING).set(false, server);
        }
    }

    public static boolean removeVanillaTraders() {
        return SpawnSettings.vanillaTrader.equals("remove");
    }

    // ------------------------------------------------------------------- status

    public static List<Component> status(MinecraftServer server) {
        ServerLevel level = server.overworld();
        StrangerSpawnData d = data(server);
        long day = day(level);
        long tod = level.getDayTime() % 24000L;
        List<Component> out = new ArrayList<>();
        out.add(Component.translatable("command.wandering_stranger.status.day", day, tod));
        if (!SpawnSettings.enabled) {
            out.add(Component.translatable("command.wandering_stranger.disabled"));
            return out;
        }
        if (!d.everSpawned && day < SpawnSettings.firstSpawnDay) {
            out.add(Component.translatable("command.wandering_stranger.status.waiting_first", SpawnSettings.firstSpawnDay));
        }
        out.add(Component.translatable("command.wandering_stranger.status.chance", chanceFor(d), d.missedDays));
        if (d.present) {
            long secs = Math.max(0L, (d.leaveAt - level.getGameTime()) / 20L);
            out.add(Component.translatable("command.wandering_stranger.status.present", secs));
        } else {
            out.add(Component.translatable("command.wandering_stranger.status.absent"));
        }
        return out;
    }

    private StrangerSpawner() {}
}
