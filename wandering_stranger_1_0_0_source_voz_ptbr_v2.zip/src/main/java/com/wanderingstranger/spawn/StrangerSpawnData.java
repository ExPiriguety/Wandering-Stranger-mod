package com.wanderingstranger.spawn;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.UUID;

/** Spawn state, stored inside the world (overworld data folder), not in a config file. */
public class StrangerSpawnData extends SavedData {
    public long lastRollDay = 0;
    public int missedDays = 0;
    public boolean everSpawned = false;
    public long lastSpawnDay = -1;
    public long pendingDay = -1;
    public boolean present = false;
    public UUID uuid = null;
    public long leaveAt = 0;

    public static StrangerSpawnData load(CompoundTag tag) {
        StrangerSpawnData d = new StrangerSpawnData();
        d.lastRollDay = tag.getLong("LastRollDay");
        d.missedDays = tag.getInt("MissedDays");
        d.everSpawned = tag.getBoolean("EverSpawned");
        d.lastSpawnDay = tag.contains("LastSpawnDay") ? tag.getLong("LastSpawnDay") : -1;
        d.pendingDay = tag.contains("PendingDay") ? tag.getLong("PendingDay") : -1;
        d.present = tag.getBoolean("Present");
        d.uuid = tag.hasUUID("Uuid") ? tag.getUUID("Uuid") : null;
        d.leaveAt = tag.getLong("LeaveAt");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLong("LastRollDay", lastRollDay);
        tag.putInt("MissedDays", missedDays);
        tag.putBoolean("EverSpawned", everSpawned);
        tag.putLong("LastSpawnDay", lastSpawnDay);
        tag.putLong("PendingDay", pendingDay);
        tag.putBoolean("Present", present);
        if (uuid != null) tag.putUUID("Uuid", uuid);
        tag.putLong("LeaveAt", leaveAt);
        return tag;
    }

    public void reset() {
        lastRollDay = 0;
        missedDays = 0;
        everSpawned = false;
        lastSpawnDay = -1;
        pendingDay = -1;
        present = false;
        uuid = null;
        leaveAt = 0;
        setDirty();
    }
}
