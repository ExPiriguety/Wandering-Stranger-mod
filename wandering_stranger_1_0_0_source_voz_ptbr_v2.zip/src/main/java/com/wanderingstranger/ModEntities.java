package com.wanderingstranger;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, WanderingStrangerMod.MOD_ID);

    public static final RegistryObject<EntityType<StrangerEntity>> STRANGER = ENTITIES.register("stranger",
            () -> EntityType.Builder.of(StrangerEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(10)
                    .build("stranger"));

    private ModEntities() {}
}
