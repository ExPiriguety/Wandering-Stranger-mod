# Wandering Stranger 1.0.0 - by Noobits (Forge 1.20.1)

Leia `PROJECT_NOTES.md` (nao entra na compilacao) para o historico completo, decisoes, mapa dos arquivos e checklist.

Compilar: copie `src/` para o Forge MDK 1.20.1 (47.3.0), ajuste o gradle.properties (veja PROJECT_NOTES secao 7), JDK 17, `gradlew build`.
Comandos (OP): /stranger summon | editor | reload | status | roll | force | reset
Config: config/wandering_stranger/trades.json
