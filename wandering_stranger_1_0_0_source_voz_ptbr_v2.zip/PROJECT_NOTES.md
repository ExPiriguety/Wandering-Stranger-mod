# PROJECT NOTES - Wandering Stranger v1.0.0 (NOT part of the build)

> This file is documentation only. It lives next to `src/`, outside of it, so it is never compiled or packaged.
> Purpose: let a person or an AI (including a future Claude chat) understand exactly how far this project went,
> how it got here, and what is still open. Written in English; short Portuguese summary just below.

**Resumo em português:** mod Forge 1.20.1 que cria um mercador ambulante próprio (substitui o vanilla), com
trocas editáveis dentro do jogo (`/stranger editor`), moeda configurável (qualquer item, inclusive itens do KubeJS),
regras de spawn por dia/chance crescente, avisos no chat e idiomas en_us (padrão) e pt_br. Criador: **Noobits**.
O código foi escrito sem poder compilar nem testar o jogo no ambiente de criação; veja "Compile risks" abaixo.

---

## 1. What this is

- Mod id `wandering_stranger`, display name "Wandering Stranger", version `1.0.0`, author **Noobits**.
- Target: Minecraft **1.20.1**, Forge **47.x** (tested target: 47.3.0), Java **17**, official (Mojang) mappings.
- Package: `com.wanderingstranger`. License field in mods.toml: `All Rights Reserved` (change if you want another).
- Everything is server-authoritative; client is needed for the model, sounds, editor GUI and language files.

## 2. How the project started (history, in order)

1. The user first asked to update a **datapack** (`dotf_weaponry_override.zip`) for the mod "Dawn of the Fallen"
   `dotf-0.6.3 (1.20.1)`. Finding: the loot-table path `data/dotf/loot_tables/chests/weaponry.json` did not change
   and the structures still use `dotf:chests/weaponry`, so the datapack kept working; only a refreshed copy was made.
   (Unrelated to this mod; mentioned only for context.)
2. The user then asked to reverse engineer **Adjustable Wandering Trader 1.0.0** (author menoXD, license
   *All Rights Reserved*, command `/adjustwanderingtrader`, config `config/adjustable_wandering_trader-trades.toml`).
   The jar was read at bytecode level (no decompiler available). Findings about its "trades reset" bug:
   - On every `EntityJoinLevelEvent` of a WanderingTrader it clears the trader's offers and re-rolls
     (5 common + 1 rare), with no "already initialised" marker -> trades and used-counters reset on every reload/restart.
   - On server start it re-saves the config unconditionally, silently dropping entries it cannot parse, and falls back
     to vanilla trades when both pools are empty; the write is not atomic.
   Because of the license, the decision was to **write a new mod from scratch** (clean room: same idea, no code reuse).
3. v0.1: custom entity + model from the user's resource pack + `/stranger summon` + JSON trades.
4. v0.2: in-game editor, item picker, currency in config. 0.2.1/0.3: model fixes, spawn system, vanilla removal, languages.
5. v1.0.0 (this): icon/logo, author, Mods-list "Config" screen, duplicated-chat-message fix, this document.

## 3. Design decisions agreed with the user

- The vanilla wandering trader is **not wanted**; only ours. Config `vanilla_trader`: `allow` | `block` | `remove`
  (default `remove`: gamerule `doTraderSpawning` set to false at server start + vanilla `wandering_trader` and
  `trader_llama` entities are cancelled on `EntityJoinLevelEvent`).
- Trades are rolled **once**, when the trader first asks for offers, and stored in the entity NBT (AbstractVillager does that).
  Never re-rolled on load. This is the core fix of the original bug.
- Config is JSON, **never rewritten automatically**. Only an OP saving from the in-game editor rewrites it
  (backup `trades.json.bak`, atomic write via tmp file). A broken file keeps the previously loaded trades.
- Currency: any item id; the placeholder `"$currency"` in trades resolves to `settings.currency`
  (default `minecraft:emerald`; the user plans a KubeJS item, e.g. a coin dropped by zombies). Unknown item -> emerald + log warning.
- A trade has 1 or 2 payment items and 1 result (vanilla MerchantOffer limits). Two pools: `common` and `special`.
- Spawn rules (user's defaults): first appearance on **day 5, guaranteed**; roll at **noon** (tick 6000);
  chance after a spawn: next day 25 %, then 50, 75, 100 (guaranteed); stays **4 minutes** (4800 ticks) then leaves
  (waits if a player is trading); appears **20-40 blocks** from a random player (Overworld, not spectator, survival/creative/adventure);
  chat announcement to everyone on arrival and on leave; if killed it counts as gone and the cycle restarts at 25 % next day;
  uses the world's own day clock (sleeping / `/time` advance it); no players online -> that day does not count.
- Languages: `en_us` is the default for every other language; `pt_br` for Brazilian Portuguese. All GUI, chat and command
  text uses translation keys. Custom chat texts in config (`spawn_message`, `leave_message`) override the translation when non-empty.

## 4. Source map (`src/main/java/com/wanderingstranger`)

| File | Role |
|---|---|
| `WanderingStrangerMod` | `@Mod` entry; registers entities, sounds, network (common setup), client config screen |
| `ModEntities`, `ModSounds` | DeferredRegisters (`stranger` entity; 8 sound events `entity.stranger.*`) |
| `StrangerEntity` | extends `WanderingTrader` (keeps compat with other mods). Offers via `StrangerTrades.fillOffers`; own sounds; `leaveAt` (NBT `StrangerLeaveAt`) -> leaves with poof particles; `die()` notifies the spawner |
| `ModEvents` | mod bus: attributes. Forge bus: commands, server starting (load trades), server started (apply vanilla mode), overworld tick (1/s -> spawner), join event (remove vanilla traders) |
| `command/StrangerCommand` | `/stranger summon [pos] | editor | reload | status | roll | force | reset` (permission level 2) |
| `trades/StrangerTrades` | loads/validates/saves `config/wandering_stranger/trades.json`; builds `MerchantOffer`s; `currentJson()` for the editor |
| `spawn/SpawnSettings` | static values parsed from the `"spawn"` block (defaults used when keys/block are missing) |
| `spawn/StrangerSpawnData` | `SavedData` (`<world>/data/wandering_stranger_spawn.dat`): last roll day, missed days, ever spawned, last spawn day, pending day, present/uuid/leaveAt |
| `spawn/StrangerSpawner` | the whole spawn algorithm, location search, announcements, status, vanilla mode |
| `network/Net`, `OpenEditorPacket`, `SaveChunkPacket` | SimpleChannel. Editor JSON goes server->client in one packet, client->server in 8000-char chunks (serverbound limit ~32 KB). Server re-checks OP level 2 |
| `client/VoiceLanguage` | client-only `PlaySoundEvent` hook: if game language is `pt_br`, swaps `entity.stranger.{ambient,trade,yes,no}` for `entity.stranger.pt_br.*` (files in `sounds/entity/stranger/pt_br/`). Other languages keep the English voice. Hurt/death/drink are not translated. |
| `client/ClientEvents`, `StrangerModel`, `StrangerRenderer` | layer + renderer registration; hand-converted model (see 6) |
| `client/ClientHooks`, `ClientInit`, `ConfigInfoScreen` | opens the editor; registers the Mods-list "Config" button -> info screen with an "open config folder" button |
| `client/gui/EditorData`, `EditorScreen`, `ItemPickerScreen`, `Ui` | the editor: tabs Common / Special / Settings, slot-based trade editing, searchable item grid, "item in hand" (keeps NBT), "currency" placeholder |

Resources: `META-INF/mods.toml`, `pack.mcmeta`, `logo.png` (256x256, ray-traced render of the stranger's bust, see tools/render_icon.py), `default_trades.json` (copied to the config
folder only if missing), `assets/wandering_stranger/{lang,sounds.json,sounds/entity/stranger/*.ogg,textures/entity/stranger.png}`.
`tools/` (outside src): `preview_model.py` (software renderer used to check the model), `render_icon.py` (ray-traces the lit bust of the real model + texture and builds the icon; 512 px, resize to 256 for logo.png). The first icon was hand-made pixel art and was rejected by the user as too pixelated/childish; the render replaced it in the final v1.0.0.

## 5. Config reference - `config/wandering_stranger/trades.json`

Blocks: `_help` (ignored), `settings`, `spawn`, `common`, `special`.

```json
"settings": { "currency": "minecraft:emerald", "common_offers": 5, "special_offers": 1 },
"spawn": {
  "enabled": true, "first_spawn_day": 5, "first_spawn_guaranteed": true,
  "spawn_time": 6000, "spawn_window_ticks": 6000,
  "initial_chance": 25, "chance_step": 25,
  "stay_ticks": 4800, "min_distance": 20, "max_distance": 40, "min_days_between": 1,
  "only_one_at_a_time": true, "wait_if_trading": true,
  "announce_spawn": true, "announce_leave": true, "spawn_message": "", "leave_message": "",
  "vanilla_trader": "remove"
},
"common":  [ { "give": [ {"item":"$currency","count":2} ], "get": {"item":"minecraft:bread","count":6}, "max_uses":12, "xp":1, "price_multiplier":0.05 } ],
"special": [ ... same shape; "give" may hold 2 items; items accept "nbt" (SNBT string) ... ]
```

Chance formula: `chance = min(100, initial_chance + chance_step * missedDays)`; 100 if never spawned and `first_spawn_guaranteed`.
`missedDays` resets to 0 on a spawn and +1 for every failed natural roll. If the dice succeeds but no valid spot exists, `pendingDay`
keeps the success and the spawner retries every second inside the window without rolling again.
"Day" in this mod = `dayTime / 24000 + 1` (day 1 is the first day), i.e. `/time query day` + 1. `/stranger status` prints the mod's day.

## 6. Model (the part most likely to need visual tuning)

Source: user's resource pack "Merchant from Resident Evil 4!" (OptiFine CEM `wandering_trader.jem`, texture 128x128). Forge cannot read CEM, so the
cuboids were converted by hand into `StrangerModel` (texture size 128x128). Conversion rules found:
`jem pivot_y(vanilla) = 24 + translate_y`; top-level box `y_rel = pivotHeightUp - y - h`; submodel (backpack) boxes use local y-up
(`y_rel = -(y+h)`); `invertAxis xy`; arms use `xRot = -0.75` like the vanilla villager (otherwise they hide inside the jacket);
`CubeDeformation` 0.51 on the hood and 0.5 on the jacket. Tunable constants: `BACKPACK_Y = 5.8F`, `BACKPACK_Z = 8.5F`,
arms `PartPose.offsetAndRotation(0, 2.95, 1.05, -0.75, 0, 0)`. A first attempt with `BACKPACK_Y = 18.2` put the pack too low
(seen in a user screenshot); 5.8 matches the iconic high pack. `tools/preview_model.py` renders front / 3-4 / side / back views with the real
texture (needs numpy + Pillow; run from the project root: `python tools/preview_model.py 5.8 -0.75 out.png`).
The user later confirmed (screenshot) the model looks correct up close.

## 7. Build instructions

1. Download the **Forge MDK for 1.20.1 (47.3.0)** and unzip it. JDK 17 required.
2. Delete the MDK's `src/` folder and copy this project's `src/` in its place.
3. In the MDK `gradle.properties` set: `mod_id=wandering_stranger`, `mod_name=Wandering Stranger`, `mod_version=1.0.0`,
   `mod_group_id=com.wanderingstranger`, `mod_authors=Noobits`, `mod_license=All Rights Reserved`.
   (`mods.toml` here is hard-coded and has no `${...}` placeholders, so it works with the MDK's resource processing.)
4. `gradlew build` -> jar in `build/libs/`. `gradlew runClient` / `runServer` to test. Remember `eula.txt` for the server.
5. This project's own `README.md`, `PROJECT_NOTES.md` and `tools/` are outside `src/` and are ignored by Gradle.

### Compile risks (the code was written from memory of the 1.20.1 / Forge 47 API and **never compiled**)

If the build fails, the likely culprits (check mapping names in the actual 1.20.1 jar):
`EntityType.Builder#build(String)`; the six `WanderingTrader` sound overrides (`getAmbientSound`, `getHurtSound(DamageSource)`,
`getDeathSound`, `getDrinkingSound(ItemStack)`, `getTradeUpdatedSound(boolean)`, `getNotifyTradeSound`) and `updateTrades()`;
`GuiGraphics` (`fill`, `drawString`, `drawCenteredString`, `renderItem`, `renderItemDecorations`, `renderTooltip(Font, ItemStack, int, int)`,
`enableScissor/disableScissor`); `Screen#mouseScrolled(double,double,double)` (3 args in 1.20.1); `EditBox#setFilter/setResponder`;
`CommandSourceStack#sendSuccess(Supplier<Component>, boolean)`; `BlockPos.containing`; `Level#hasChunk(int,int)`;
`EntityType#getAABB(double,double,double)`; `SavedData` + `DimensionDataStorage#computeIfAbsent(load, create, id)`;
`TickEvent.LevelTickEvent#level`; `EntityJoinLevelEvent#getLevel()`; `SimpleChannel#registerMessage`;
`DistExecutor.unsafeRunWhenOn`; `ConfigScreenHandler.ConfigScreenFactory`; `Util.getPlatform().openFile(File)`;
`GameRules.RULE_DO_TRADER_SPAWNING`. Fixing a compile error should never require changing behaviour - keep the logic described here.

## 8. Test checklist

1. Game starts, Mods list shows the logo, author "Noobits" and a working **Config** button.
2. `/stranger summon`: the stranger looks like the Merchant (hood, crossed arms in front, tall pack); right-click opens trades.
3. Trade something, quit the world, re-enter: offers and used counters are unchanged.
4. `/stranger editor` (OP): edit, add, duplicate, delete, reorder trades; pick an item from the grid, "item in hand", currency slot; Save.
   Existing traders keep their old offers; kill them (`/kill @e[type=wandering_stranger:stranger]`) and summon a new one to see new offers.
5. `/stranger status`, `/stranger force` (one chat announcement, no duplicate confirmation), wait `stay_ticks` -> leave message + poof.
   Tip: set `stay_ticks` to 600 for a quick test; `/stranger reload` after editing the file.
6. `/stranger reset` returns to "first appearance on day 5".
7. With `vanilla_trader: remove`, `/summon wandering_trader` does nothing and vanilla traders do not appear.

## 9. Known limitations / not done

- **No "Spawn" tab in the editor yet.** The `spawn` block must be edited in the file. A `trades.json` created before v0.3 lacks the
  block (defaults apply); copy it from `default_trades.json`. The mod never rewrites the file on its own.
- The editor drops trades whose structure is broken (missing `give`/`get`); items from missing mods are kept as barrier icons.
- `vanilla_trader: allow` does not turn `doTraderSpawning` back on if it was disabled earlier.
- No pack llamas, no skin variants/profiles per visit (the original "special profiles" idea) - only common/special pools.
- Trading with `min_days_between` and `spawn_window_ticks` are extras added by the assistant, not asked for explicitly.
- Packet text uses UTF-16 chunking; an emoji split across two chunks would corrupt NBT text (practically never happens).

- **Voice language (added after 1.0.0):** Portuguese voice set has fewer variations than English (idle 4/5, haggle 3/3, yes 3/4, no 4/5). Audio converted WAV -> mono OGG, gain -9 dB to match the original lines' loudness. To add more pt lines, drop an `.ogg` into `pt_br/` and list it in `sounds.json`.

## 10. Assets and rights (read before publishing)

- `logo.png` / the 512 px icon are **renders of the model with the pack texture**, so they carry the same rights situation as the texture below. If you replace the texture, re-run `tools/render_icon.py` to get a matching icon.
- `textures/entity/stranger.png`, the model proportions and the 29 `.ogg` files in `sounds/entity/stranger/` come from the community pack
  "Merchant from Resident Evil 4!" (Resident Evil 4 is Capcom IP; the pack author is not named in its `pack.mcmeta`).
  Fine for private/modpack testing; **before publishing on CurseForge/Modrinth, get permission or replace them**
  (swap the PNG with the same 128x128 layout, replace the `.ogg` files and keep the names listed in `sounds.json`).
- The original mod (Adjustable Wandering Trader) was only read to understand its bug; none of its code is used.

## 11. User profile / preferences (for a new chat)

The user (Noobits) writes in Brazilian Portuguese, by voice dictation (sentences can be loose). They run a modpack with KubeJS, want
English as default language and pt_br as secondary, prefer being asked about big design choices first, and want short progress
reports. They cannot compile locally and will pass this project to another AI/person to build.

## 12. Prompt you can give a compiling AI

"Build this Forge 1.20.1 (47.3.0) mod: copy `src/` into the official MDK, set the gradle.properties from NOTES section 7, run `gradlew build`.
Fix compile errors without changing behaviour, then report every change you made. Do not rewrite the spawn rules or the config format."
